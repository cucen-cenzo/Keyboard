package com.godfather.keyboard;

/** How a key looks: a frosted-glass gradient (top to bottom), a thin edge, and a brighter pressed state. */
final class Skin {
    final int top;
    final int bottom;
    final int border;          // 0 = no edge
    final int pressTop;
    final int pressBottom;
    final boolean shine;       // bright hairline along the top edge, like light on glass
    final boolean flat;        // invisible until pressed (suggestion slots)

    Skin(int top, int bottom, int border, int pressTop, int pressBottom, boolean shine, boolean flat) {
        this.top = top;
        this.bottom = bottom;
        this.border = border;
        this.pressTop = pressTop;
        this.pressBottom = pressBottom;
        this.shine = shine;
        this.flat = flat;
    }
}
