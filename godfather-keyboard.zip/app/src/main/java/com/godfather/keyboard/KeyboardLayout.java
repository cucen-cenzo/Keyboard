package com.godfather.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Root of the keyboard. While the keys are showing it handles every touch itself:
 *  - each finger goes to the NEAREST key, so the small gaps between keys and the screen edges
 *    are not dead space (a key's "cell" is the key plus half the gap on every side);
 *  - fingers are tracked separately (two thumbs, fast rolling), and a finger can slide to
 *    another key before lifting, so the key under the finger at lift is the one typed;
 *  - a popup bubble shows the letter above the key being pressed.
 * When the clipboard list is showing, touches go to the list as normal.
 */
final class KeyboardLayout extends LinearLayout {

    private final List<KeyView> keys = new ArrayList<>();
    private final List<float[]> cells = new ArrayList<>();   // {left, top, right, bottom} in this view
    private final Map<Integer, KeyView> active = new HashMap<>();
    private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bubbleText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bubbleRect = new RectF();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Shader glowIce;
    private Shader glowViolet;
    private Shader glowMist;

    private ViewGroup keyPane;
    private float maxReach = Float.MAX_VALUE;
    private float bubbleRadius = 20f;
    private float bubbleExtra = 16f;
    private float bubbleGap = 6f;

    KeyboardLayout(Context context) {
        super(context);
        bubblePaint.setColor(0xF2E3F4FF);          // frosted white-blue pop-up
        bubbleText.setColor(0xFF0A2236);
        bubbleText.setTextAlign(Paint.Align.CENTER);
        setWillNotDraw(false);
    }

    // ------------------------------------------------------------------ frost glow behind the keys

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        glowIce = new RadialGradient(w * 0.12f, h * 0.02f, w * 0.75f, 0x5537C8FF, 0x0037C8FF, Shader.TileMode.CLAMP);
        glowViolet = new RadialGradient(w * 0.95f, h * 1.0f, w * 0.85f, 0x445B7CFF, 0x005B7CFF, Shader.TileMode.CLAMP);
        glowMist = new RadialGradient(w * 0.55f, h * 0.30f, w * 0.60f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (glowIce == null) return;
        float w = getWidth();
        float h = getHeight();
        glowPaint.setShader(glowIce);
        canvas.drawRect(0f, 0f, w, h, glowPaint);
        glowPaint.setShader(glowViolet);
        canvas.drawRect(0f, 0f, w, h, glowPaint);
        glowPaint.setShader(glowMist);
        canvas.drawRect(0f, 0f, w, h, glowPaint);
        glowPaint.setShader(null);
    }

    /** The pane that holds the key rows. Touches go to its keys while it is visible. */
    void setKeyPane(ViewGroup pane) {
        keyPane = pane;
    }

    /** A touch farther than this (pixels) from every key is ignored. */
    void setMaxReach(float px) {
        maxReach = px;
    }

    void setBubbleSizes(float radius, float extraWidth, float gap) {
        bubbleRadius = radius;
        bubbleExtra = extraWidth;
        bubbleGap = gap;
    }

    // ------------------------------------------------------------------ key cells

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        rebuildCells();
    }

    private void rebuildCells() {
        keys.clear();
        cells.clear();
        if (keyPane == null) return;
        for (int i = 0; i < keyPane.getChildCount(); i++) {
            View row = keyPane.getChildAt(i);
            if (!(row instanceof ViewGroup)) continue;
            ViewGroup rowGroup = (ViewGroup) row;
            for (int j = 0; j < rowGroup.getChildCount(); j++) {
                View v = rowGroup.getChildAt(j);
                if (!(v instanceof KeyView)) continue;
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
                float left = keyPane.getLeft() + row.getLeft() + v.getLeft();
                float top = keyPane.getTop() + row.getTop() + v.getTop();
                keys.add((KeyView) v);
                cells.add(new float[]{
                        left - lp.leftMargin,
                        top - lp.topMargin,
                        left + v.getWidth() + lp.rightMargin,
                        top + v.getHeight() + lp.bottomMargin});
            }
        }
    }

    /** The key whose cell contains the point, or the closest one if it is in a gap or at the edge. */
    private KeyView nearest(float x, float y) {
        KeyView best = null;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i < cells.size(); i++) {
            float[] c = cells.get(i);
            float dx = x < c[0] ? c[0] - x : (x > c[2] ? x - c[2] : 0f);
            float dy = y < c[1] ? c[1] - y : (y > c[3] ? y - c[3] : 0f);
            float d = dx * dx + dy * dy;
            if (d < bestD) {
                bestD = d;
                best = keys.get(i);
                if (d == 0f) break;
            }
        }
        if (best != null && maxReach != Float.MAX_VALUE && bestD > maxReach * maxReach) return null;
        return best;
    }

    // ------------------------------------------------------------------ touches

    private boolean handlingKeys() {
        return keyPane != null && keyPane.getVisibility() == View.VISIBLE;
    }

    /** Let go of every finger without typing anything (for example when the clipboard opens). */
    void cancelAll() {
        for (KeyView k : new ArrayList<>(active.values())) k.release(false);
        active.clear();
        invalidate();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (!handlingKeys()) return super.dispatchTouchEvent(ev);

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = ev.getActionIndex();
                pressAt(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < ev.getPointerCount(); i++) {
                    moveTo(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = ev.getActionIndex();
                liftAt(ev.getPointerId(i), true);
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                cancelAll();
                break;
            default:
                break;
        }
        return true;
    }

    private void pressAt(int id, float x, float y) {
        KeyView k = nearest(x, y);
        if (k == null) return;
        active.put(id, k);
        k.press(true);
        invalidate();
    }

    private void moveTo(int id, float x, float y) {
        KeyView current = active.get(id);
        if (current == null) return;
        KeyView k = nearest(x, y);
        if (k == current) return;
        current.release(false);                 // slid off: nothing typed for the old key
        if (k == null) active.remove(id);
        else {
            active.put(id, k);
            k.press(false);                      // slid onto: highlight only, no tick, no instant action
        }
        invalidate();
    }

    private void liftAt(int id, boolean commit) {
        KeyView current = active.remove(id);
        if (current == null) return;
        current.release(commit);
        invalidate();
    }

    // ------------------------------------------------------------------ popup bubble

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (active.isEmpty()) return;
        for (KeyView k : active.values()) {
            if (!k.isPreviewable()) continue;
            int index = keys.indexOf(k);
            if (index < 0) continue;
            float[] c = cells.get(index);
            float keyH = k.getHeight();
            float keyTop = c[1] + ((c[3] - c[1]) - keyH) / 2f;
            float w = k.getWidth() + bubbleExtra;
            float h = keyH * 1.08f;
            float centerX = (c[0] + c[2]) / 2f;
            float left = Math.max(0f, Math.min(centerX - w / 2f, getWidth() - w));
            float top = Math.max(0f, keyTop - bubbleGap - h);
            bubbleRect.set(left, top, left + w, top + h);
            canvas.drawRoundRect(bubbleRect, bubbleRadius, bubbleRadius, bubblePaint);
            bubbleText.setTextSize(k.getTextSizePx() * 1.25f);
            float y = (top + h / 2f) - (bubbleText.descent() + bubbleText.ascent()) / 2f;
            canvas.drawText(k.getLabel(), left + w / 2f, y, bubbleText);
        }
    }
}
