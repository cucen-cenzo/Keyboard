package com.godfather.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.HapticFeedbackConstants;
import android.view.View;

/**
 * A flat, light key. It draws its own rounded rectangle, label or icon, so a press repaints only
 * this key and instantly (no Button theme, no state drawables). It does not read touches itself:
 * KeyboardLayout finds the nearest key for every finger and calls press() / release().
 * A key fires when the finger lifts on it; only delete (fireOnDown) fires the moment it is pressed.
 */
final class KeyView extends View {

    interface Action {
        void run();
    }

    enum Icon { NONE, SHIFT, SHIFT_ON, SHIFT_LOCK, BACKSPACE, ENTER }

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final float baseTextSize;
    private final float radius;
    private final boolean fireOnDown;
    private final int pressedColor;

    private String label;
    private Icon icon = Icon.NONE;
    private int color;
    private int textColor;
    private boolean down;
    private boolean previewable;
    private Action action;
    private Action onRelease;
    private float cx, cy, unit;      // scratch values while drawing an icon

    KeyView(Context context, String label, float textPx, int color, int textColor, int pressedColor,
            float radiusPx, boolean fireOnDown) {
        super(context);
        this.label = label;
        this.color = color;
        this.textColor = textColor;
        this.pressedColor = pressedColor;
        this.radius = radiusPx;
        this.fireOnDown = fireOnDown;
        this.baseTextSize = textPx;
        textPaint.setTextAlign(Paint.Align.CENTER);
        iconPaint.setStrokeCap(Paint.Cap.ROUND);
        iconPaint.setStrokeJoin(Paint.Join.ROUND);
        setSoundEffectsEnabled(false);
        setContentDescription(label);
    }

    void setAction(Action a) {
        this.action = a;
    }

    void setOnRelease(Action a) {
        this.onRelease = a;
    }

    void setIcon(Icon i) {
        if (i != icon) {
            icon = i;
            invalidate();
        }
    }

    void setLabel(String text) {
        if (!text.equals(label)) {
            label = text;
            invalidate();
        }
    }

    void setColor(int c) {
        if (c != color) {
            color = c;
            invalidate();
        }
    }

    void setTextTint(int c) {
        if (c != textColor) {
            textColor = c;
            invalidate();
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        rect.set(0, 0, getWidth(), getHeight());
        bgPaint.setColor(down ? pressedColor : color);
        canvas.drawRoundRect(rect, radius, radius, bgPaint);

        if (icon != Icon.NONE) {
            drawIcon(canvas);
            return;
        }
        textPaint.setColor(textColor);
        textPaint.setTextSize(baseTextSize);
        float room = getWidth() * 0.84f;
        float wide = textPaint.measureText(label);
        if (wide > room && room > 0f) textPaint.setTextSize(baseTextSize * room / wide);   // shrink to fit
        float y = getHeight() / 2f - (textPaint.descent() + textPaint.ascent()) / 2f;
        canvas.drawText(label, getWidth() / 2f, y, textPaint);
    }

    private void moveU(float x, float y) {
        path.moveTo(cx + x * unit, cy + y * unit);
    }

    private void lineU(float x, float y) {
        path.lineTo(cx + x * unit, cy + y * unit);
    }

    private void drawIcon(Canvas c) {
        cx = getWidth() / 2f;
        cy = getHeight() / 2f;
        unit = Math.min(getWidth(), getHeight()) * 0.20f;
        iconPaint.setColor(textColor);
        iconPaint.setStrokeWidth(Math.max(2f, unit * 0.2f));
        iconPaint.setStyle(Paint.Style.STROKE);
        path.reset();

        switch (icon) {
            case SHIFT:
            case SHIFT_ON:
            case SHIFT_LOCK:
                moveU(0f, -1f);
                lineU(0.95f, -0.1f);
                lineU(0.45f, -0.1f);
                lineU(0.45f, 0.85f);
                lineU(-0.45f, 0.85f);
                lineU(-0.45f, -0.1f);
                lineU(-0.95f, -0.1f);
                path.close();
                if (icon != Icon.SHIFT) iconPaint.setStyle(Paint.Style.FILL_AND_STROKE);
                c.drawPath(path, iconPaint);
                if (icon == Icon.SHIFT_LOCK) {
                    iconPaint.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx - 0.45f * unit, cy + 1.35f * unit, cx + 0.45f * unit, cy + 1.35f * unit, iconPaint);
                }
                break;
            case BACKSPACE:
                moveU(-1f, 0f);
                lineU(-0.45f, -0.75f);
                lineU(1f, -0.75f);
                lineU(1f, 0.75f);
                lineU(-0.45f, 0.75f);
                path.close();
                c.drawPath(path, iconPaint);
                c.drawLine(cx + 0.05f * unit, cy - 0.28f * unit, cx + 0.6f * unit, cy + 0.28f * unit, iconPaint);
                c.drawLine(cx + 0.6f * unit, cy - 0.28f * unit, cx + 0.05f * unit, cy + 0.28f * unit, iconPaint);
                break;
            case ENTER:
                moveU(0.95f, -0.8f);
                lineU(0.95f, 0.2f);
                lineU(-0.75f, 0.2f);
                c.drawPath(path, iconPaint);
                path.reset();
                moveU(-0.2f, -0.4f);
                lineU(-0.75f, 0.2f);
                lineU(-0.2f, 0.8f);
                c.drawPath(path, iconPaint);
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ press / release

    private void setDown(boolean value) {
        if (down != value) {
            down = value;
            invalidate();
        }
    }

    /** initial = the finger just landed here (not slid over from another key). */
    void press(boolean initial) {
        setDown(true);
        if (initial) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            if (fireOnDown && action != null) action.run();
        }
    }

    /** commit = the finger lifted on this key, so run its action (unless it already fired on press). */
    void release(boolean commit) {
        setDown(false);
        if (commit && !fireOnDown && action != null) action.run();
        if (onRelease != null) onRelease.run();
    }

    // ------------------------------------------------------------------ popup bubble support

    void setPreview(boolean on) {
        previewable = on;
    }

    boolean isPreviewable() {
        return previewable && icon == Icon.NONE && label.length() > 0;
    }

    String getLabel() {
        return label;
    }

    float getTextSizePx() {
        return baseTextSize;
    }
}
