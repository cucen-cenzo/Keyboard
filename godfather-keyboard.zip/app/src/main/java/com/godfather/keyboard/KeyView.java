package com.godfather.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.TypedValue;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/**
 * A flat, light key. It draws its own rounded rectangle and label, so a press repaints only
 * this key and instantly (no Button theme, no state drawables). Typing keys fire the moment the
 * finger lands; utility keys fire when the finger lifts.
 */
final class KeyView extends View {

    interface Action {
        void run();
    }

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float baseTextSize;
    private final float radius;
    private final boolean fireOnDown;
    private final int pressedColor;

    private String label;
    private int color;
    private int textColor;
    private boolean down;
    private Action action;
    private Action onRelease;

    KeyView(Context context, String label, int sp, int color, int textColor, int pressedColor,
            float radiusPx, boolean fireOnDown) {
        super(context);
        this.label = label;
        this.color = color;
        this.textColor = textColor;
        this.pressedColor = pressedColor;
        this.radius = radiusPx;
        this.fireOnDown = fireOnDown;
        this.baseTextSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, sp, context.getResources().getDisplayMetrics());
        textPaint.setTextAlign(Paint.Align.CENTER);
        setSoundEffectsEnabled(false);
        setContentDescription(label);
    }

    void setAction(Action a) {
        this.action = a;
    }

    void setOnRelease(Action a) {
        this.onRelease = a;
    }

    void setLabel(String text) {
        if (!text.equals(label)) {
            label = text;
            invalidate();
        }
    }

    void setColor(int c) {
        if (c != color) {
            color = c;
            invalidate();
        }
    }

    void setTextTint(int c) {
        if (c != textColor) {
            textColor = c;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        rect.set(0, 0, getWidth(), getHeight());
        bgPaint.setColor(down ? pressedColor : color);
        canvas.drawRoundRect(rect, radius, radius, bgPaint);

        textPaint.setColor(textColor);
        textPaint.setTextSize(baseTextSize);
        float room = getWidth() - 12 * 2f;
        float wide = textPaint.measureText(label);
        if (wide > room && room > 0f) textPaint.setTextSize(baseTextSize * room / wide);   // shrink to fit
        float y = getHeight() / 2f - (textPaint.descent() + textPaint.ascent()) / 2f;
        canvas.drawText(label, getWidth() / 2f, y, textPaint);
    }

    private void setDown(boolean value) {
        if (down != value) {
            down = value;
            invalidate();
        }
    }

    private boolean inside(MotionEvent e) {
        return e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                setDown(true);
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                if (fireOnDown && action != null) action.run();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (down && !fireOnDown && !inside(e)) setDown(false);   // finger slid off a utility key
                return true;
            case MotionEvent.ACTION_UP: {
                boolean wasDown = down;
                setDown(false);
                if (!fireOnDown && wasDown && inside(e) && action != null) action.run();
                if (onRelease != null) onRelease.run();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                setDown(false);
                if (onRelease != null) onRelease.run();
                return true;
            default:
                return true;
        }
    }
}
