package com.godfather.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/**
 * A frosted-glass key. It draws its own rounded rectangle, label or icon, so a press repaints only
 * this key and instantly (no Button theme, no state drawables).
 * On the main keyboard, KeyboardLayout finds the nearest key for every finger and calls
 * press() / release(). Anywhere else (the clipboard screen's back / clear all) the key reads its
 * own touch below. A key fires when the finger lifts on it; only delete (fireOnDown) fires on press.
 */
final class KeyView extends View {

    interface Action {
        void run();
    }

    enum Icon { NONE, SHIFT, SHIFT_ON, SHIFT_LOCK, BACKSPACE, ENTER, CLIP, EMOJI }

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final float baseTextSize;
    private final float radius;
    private final boolean fireOnDown;

    private Skin skin;
    private Shader normalShader;
    private Shader pressedShader;
    private String label;
    private Icon icon = Icon.NONE;
    private int textColor;
    private boolean down;
    private float pressAmount;         // 1 = fully pressed, fades to 0 on release (ease-out)
    private ValueAnimator releaseAnim;
    private boolean previewable;
    private boolean bold;
    private boolean divider;           // thin line on the right edge (between suggestion slots)
    private String subLabel;           // small second line (the counter)
    private int subColor = 0xFF9A9AA3;
    private float progress = -1f;      // 0..1 thin bar along the bottom, -1 = none
    private int progressColor;
    private int dot;                   // little status dot left of the label, 0 = none
    private int outline;               // accent outline around the key, 0 = none
    private Action action;
    private Action onRelease;
    private float cx, cy, unit;        // scratch values while drawing an icon

    KeyView(Context context, String label, float textPx, Skin skin, int textColor,
            float radiusPx, boolean fireOnDown) {
        super(context);
        this.label = label;
        this.skin = skin;
        this.textColor = textColor;
        this.radius = radiusPx;
        this.fireOnDown = fireOnDown;
        this.baseTextSize = textPx;
        textPaint.setTextAlign(Paint.Align.CENTER);
        subPaint.setTextAlign(Paint.Align.CENTER);
        linePaint.setStyle(Paint.Style.STROKE);
        iconPaint.setStrokeCap(Paint.Cap.ROUND);
        iconPaint.setStrokeJoin(Paint.Join.ROUND);
        setSoundEffectsEnabled(false);
        setContentDescription(label);
    }

    void setAction(Action a) {
        this.action = a;
    }

    void setOnRelease(Action a) {
        this.onRelease = a;
    }

    void setIcon(Icon i) {
        if (i != icon) {
            icon = i;
            invalidate();
        }
    }

    void setLabel(String text) {
        if (!text.equals(label)) {
            label = text;
            invalidate();
        }
    }

    void setSkin(Skin s) {
        if (s != skin) {
            skin = s;
            normalShader = null;
            pressedShader = null;
            invalidate();
        }
    }

    void setBold(boolean b) {
        if (b != bold) {
            bold = b;
            invalidate();
        }
    }

    void setDivider(boolean on) {
        divider = on;
    }

    void setSubLabel(String text) {
        if (text == null ? subLabel != null : !text.equals(subLabel)) {
            subLabel = text;
            invalidate();
        }
    }

    void setProgress(float p, int c) {
        if (p != progress || c != progressColor) {
            progress = p;
            progressColor = c;
            invalidate();
        }
    }

    void setDot(int c) {
        if (c != dot) {
            dot = c;
            invalidate();
        }
    }

    void setOutline(int c) {
        if (c != outline) {
            outline = c;
            invalidate();
        }
    }

    void setTextTint(int c) {
        if (c != textColor) {
            textColor = c;
            invalidate();
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        normalShader = null;
        pressedShader = null;
    }

    private void ensureShaders() {
        float h = getHeight();
        if (normalShader == null) normalShader = new LinearGradient(0f, 0f, 0f, h, skin.top, skin.bottom, Shader.TileMode.CLAMP);
        if (pressedShader == null) pressedShader = new LinearGradient(0f, 0f, 0f, h, skin.pressTop, skin.pressBottom, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        ensureShaders();

        // frosted fill: resting glass, with the pressed glass faded over it
        rect.set(0, 0, w, h);
        if (!skin.flat) {
            bgPaint.setShader(normalShader);
            bgPaint.setAlpha(255);
            canvas.drawRoundRect(rect, radius, radius, bgPaint);
        }
        if (pressAmount > 0f) {
            bgPaint.setShader(pressedShader);
            bgPaint.setAlpha(Math.round(255f * pressAmount));
            canvas.drawRoundRect(rect, radius, radius, bgPaint);
        }
        bgPaint.setShader(null);
        bgPaint.setAlpha(255);

        // glass edge and the bright line along the top
        if (skin.border != 0 && !skin.flat) {
            float sw = Math.max(1.5f, h * 0.018f);
            linePaint.setStrokeWidth(sw);
            linePaint.setColor(skin.border);
            rect.set(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f);
            canvas.drawRoundRect(rect, radius, radius, linePaint);
        }
        if (skin.shine && !skin.flat) {
            float sw = Math.max(1.5f, h * 0.02f);
            linePaint.setStrokeWidth(sw);
            linePaint.setColor(0x80FFFFFF);
            float inset = Math.min(radius * 0.85f, w / 3f);
            canvas.drawLine(inset, sw * 1.4f, w - inset, sw * 1.4f, linePaint);
        }
        if (outline != 0) {
            float sw = Math.max(2f, h * 0.03f);
            linePaint.setStrokeWidth(sw);
            linePaint.setColor(outline);
            rect.set(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f);
            canvas.drawRoundRect(rect, radius, radius, linePaint);
        }
        if (divider) {
            linePaint.setStrokeWidth(Math.max(1.5f, h * 0.015f));
            linePaint.setColor(0x4DFFFFFF);
            canvas.drawLine(w - 1f, h * 0.24f, w - 1f, h * 0.76f, linePaint);
        }

        if (icon != Icon.NONE) {
            drawIcon(canvas);
            return;
        }
        if (label.length() == 0 && subLabel == null) return;

        boolean two = subLabel != null;
        textPaint.setFakeBoldText(bold);
        textPaint.setColor(textColor);
        textPaint.setTextSize(baseTextSize);
        float dotSpace = dot != 0 ? h * 0.40f : 0f;           // room for the dot and its gap
        float room = w * 0.86f - dotSpace;
        float wide = textPaint.measureText(label);
        if (wide > room && room > 0f) {                         // shrink to fit
            textPaint.setTextSize(baseTextSize * room / wide);
            wide = room;
        }
        float textX = w / 2f + dotSpace / 2f;
        float baseline = two ? h * 0.44f : h / 2f - (textPaint.descent() + textPaint.ascent()) / 2f;
        canvas.drawText(label, textX, baseline, textPaint);

        if (dot != 0) {
            barPaint.setColor(dot);
            canvas.drawCircle(textX - wide / 2f - h * 0.20f, h / 2f, h * 0.08f, barPaint);
        }

        if (two) {
            subPaint.setColor(subColor);
            subPaint.setTextSize(baseTextSize * 0.72f);
            float subRoom = w * 0.86f;
            float subWide = subPaint.measureText(subLabel);
            if (subWide > subRoom && subRoom > 0f) subPaint.setTextSize(baseTextSize * 0.72f * subRoom / subWide);
            canvas.drawText(subLabel, w / 2f, h * 0.74f, subPaint);
        }

        if (progress >= 0f) {
            float pad = w * 0.09f;
            float barH = Math.max(3f, h * 0.07f);
            float top = h - barH - h * 0.09f;
            barPaint.setColor(0x33FFFFFF);
            rect.set(pad, top, w - pad, top + barH);
            canvas.drawRoundRect(rect, barH / 2f, barH / 2f, barPaint);
            float fill = (w - 2f * pad) * Math.max(0f, Math.min(1f, progress));
            if (fill > 0f) {
                barPaint.setColor(progressColor);
                rect.set(pad, top, pad + Math.max(fill, barH), top + barH);
                canvas.drawRoundRect(rect, barH / 2f, barH / 2f, barPaint);
            }
        }
    }

    private void moveU(float x, float y) {
        path.moveTo(cx + x * unit, cy + y * unit);
    }

    private void lineU(float x, float y) {
        path.lineTo(cx + x * unit, cy + y * unit);
    }

    private void drawIcon(Canvas c) {
        cx = getWidth() / 2f;
        cy = getHeight() / 2f;
        unit = Math.min(getWidth(), getHeight()) * 0.20f;
        iconPaint.setColor(textColor);
        iconPaint.setStrokeWidth(Math.max(2f, unit * 0.2f));
        iconPaint.setStyle(Paint.Style.STROKE);
        path.reset();

        switch (icon) {
            case SHIFT:
            case SHIFT_ON:
            case SHIFT_LOCK:
                moveU(0f, -1f);
                lineU(0.95f, -0.1f);
                lineU(0.45f, -0.1f);
                lineU(0.45f, 0.85f);
                lineU(-0.45f, 0.85f);
                lineU(-0.45f, -0.1f);
                lineU(-0.95f, -0.1f);
                path.close();
                if (icon != Icon.SHIFT) iconPaint.setStyle(Paint.Style.FILL_AND_STROKE);
                c.drawPath(path, iconPaint);
                if (icon == Icon.SHIFT_LOCK) {
                    iconPaint.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx - 0.45f * unit, cy + 1.35f * unit, cx + 0.45f * unit, cy + 1.35f * unit, iconPaint);
                }
                break;
            case BACKSPACE:
                moveU(-1f, 0f);
                lineU(-0.45f, -0.75f);
                lineU(1f, -0.75f);
                lineU(1f, 0.75f);
                lineU(-0.45f, 0.75f);
                path.close();
                c.drawPath(path, iconPaint);
                c.drawLine(cx + 0.05f * unit, cy - 0.28f * unit, cx + 0.6f * unit, cy + 0.28f * unit, iconPaint);
                c.drawLine(cx + 0.6f * unit, cy - 0.28f * unit, cx + 0.05f * unit, cy + 0.28f * unit, iconPaint);
                break;
            case CLIP:
                rect.set(cx - 0.8f * unit, cy - 0.7f * unit, cx + 0.8f * unit, cy + 1.0f * unit);
                c.drawRoundRect(rect, 0.22f * unit, 0.22f * unit, iconPaint);
                iconPaint.setStyle(Paint.Style.FILL_AND_STROKE);
                rect.set(cx - 0.42f * unit, cy - 1.0f * unit, cx + 0.42f * unit, cy - 0.45f * unit);
                c.drawRoundRect(rect, 0.18f * unit, 0.18f * unit, iconPaint);
                iconPaint.setStyle(Paint.Style.STROKE);
                c.drawLine(cx - 0.4f * unit, cy + 0.12f * unit, cx + 0.4f * unit, cy + 0.12f * unit, iconPaint);
                c.drawLine(cx - 0.4f * unit, cy + 0.55f * unit, cx + 0.2f * unit, cy + 0.55f * unit, iconPaint);
                break;
            case EMOJI:
                // a plain smiley in the same line style as the clipboard icon: ring, two eyes, smile
                c.drawCircle(cx, cy, 1.05f * unit, iconPaint);
                iconPaint.setStyle(Paint.Style.FILL);
                c.drawCircle(cx - 0.38f * unit, cy - 0.3f * unit, 0.11f * unit, iconPaint);
                c.drawCircle(cx + 0.38f * unit, cy - 0.3f * unit, 0.11f * unit, iconPaint);
                iconPaint.setStyle(Paint.Style.STROKE);
                rect.set(cx - 0.55f * unit, cy - 0.45f * unit, cx + 0.55f * unit, cy + 0.55f * unit);
                c.drawArc(rect, 25f, 130f, false, iconPaint);
                break;
            case ENTER:
                moveU(0.95f, -0.8f);
                lineU(0.95f, 0.2f);
                lineU(-0.75f, 0.2f);
                c.drawPath(path, iconPaint);
                path.reset();
                moveU(-0.2f, -0.4f);
                lineU(-0.75f, 0.2f);
                lineU(-0.2f, 0.8f);
                c.drawPath(path, iconPaint);
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ press / release

    // Press is instant: typing is the most repeated action there is, so it must never wait on an
    // animation. Release eases out (fast start, soft landing) so the key settles instead of snapping.
    private void setDown(boolean value) {
        if (down == value) return;
        down = value;
        if (releaseAnim != null) {
            releaseAnim.cancel();
            releaseAnim = null;
        }
        if (value) {
            pressAmount = 1f;
        } else {
            final float from = pressAmount;
            releaseAnim = ValueAnimator.ofFloat(from, 0f);
            releaseAnim.setDuration(130);
            releaseAnim.setInterpolator(new DecelerateInterpolator(1.6f));
            releaseAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    pressAmount = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            releaseAnim.start();
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (releaseAnim != null) releaseAnim.cancel();
        super.onDetachedFromWindow();
    }

    /** initial = the finger just landed here (not slid over from another key). */
    void press(boolean initial) {
        setDown(true);
        if (initial) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            if (fireOnDown && action != null) action.run();
        }
    }

    /** commit = the finger lifted on this key, so run its action (unless it already fired on press). */
    void release(boolean commit) {
        setDown(false);
        if (commit && !fireOnDown && action != null) action.run();
        if (onRelease != null) onRelease.run();
    }

    // ------------------------------------------------------------------ own touch (used outside the keyboard grid)

    private boolean inside(MotionEvent e) {
        return e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                press(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (down && !inside(e)) release(false);        // slid off the key: cancel
                return true;
            case MotionEvent.ACTION_UP:
                if (down) release(inside(e));
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (down) release(false);
                return true;
            default:
                return true;
        }
    }

    // ------------------------------------------------------------------ swipe gestures (run by KeyboardLayout)

    private int swipeMode;     // 0 = none, 1 = swiping moves the cursor (space bar), 2 = swiping deletes words (backspace)

    void setSwipeMode(int mode) {
        swipeMode = mode;
    }

    int getSwipeMode() {
        return swipeMode;
    }

    // ------------------------------------------------------------------ popup bubble support

    void setPreview(boolean on) {
        previewable = on;
    }

    boolean isPreviewable() {
        return previewable && icon == Icon.NONE && label.length() > 0;
    }

    String getLabel() {
        return label;
    }

    float getTextSizePx() {
        return baseTextSize;
    }
}
