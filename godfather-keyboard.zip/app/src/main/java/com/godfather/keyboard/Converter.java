package com.godfather.keyboard;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Same conversion as the godfather website (index.html), ported line for line.
 *
 * Text is flipped in GROUPS of words: LRI RLO (group reversed) [PDF] PDI, so it reads
 * normally but keeps word order when the chat wraps it. Groups are as big as they can be
 * without a chat line break being able to land inside them (estimated with glyph widths),
 * and the extras (PDF, then ZWJ) are trimmed until the result fits the chat's point limit.
 */
public final class Converter {

    public static final int POINT_BUDGET = 100;

    private static final String RLO = "\u202e";
    private static final String ZWJ = "\u200d";
    private static final String PDF = "\u202c";
    private static final String LRI = "\u2066";
    private static final String PDI = "\u2069";

    private static final int SPACE_W = 278;
    // One chat line held up to 21955 and never reached 22177 in these units; 2.5% margin each side.
    private static final double CAP_LO = 21955 * 0.975;
    private static final double CAP_HI = 22177 * 1.025;

    private static final Map<Integer, Integer> GW = new HashMap<>();
    static {
        GW.put(0x61, 556); // "a"
        GW.put(0x62, 556); // "b"
        GW.put(0x63, 500); // "c"
        GW.put(0x64, 556); // "d"
        GW.put(0x65, 556); // "e"
        GW.put(0x66, 278); // "f"
        GW.put(0x67, 556); // "g"
        GW.put(0x68, 556); // "h"
        GW.put(0x69, 222); // "i"
        GW.put(0x6A, 222); // "j"
        GW.put(0x6B, 500); // "k"
        GW.put(0x6C, 222); // "l"
        GW.put(0x6D, 833); // "m"
        GW.put(0x6E, 556); // "n"
        GW.put(0x6F, 556); // "o"
        GW.put(0x70, 556); // "p"
        GW.put(0x71, 556); // "q"
        GW.put(0x72, 333); // "r"
        GW.put(0x73, 500); // "s"
        GW.put(0x74, 278); // "t"
        GW.put(0x75, 556); // "u"
        GW.put(0x76, 500); // "v"
        GW.put(0x77, 722); // "w"
        GW.put(0x78, 500); // "x"
        GW.put(0x79, 500); // "y"
        GW.put(0x7A, 500); // "z"
        GW.put(0x41, 667); // "A"
        GW.put(0x42, 667); // "B"
        GW.put(0x43, 722); // "C"
        GW.put(0x44, 722); // "D"
        GW.put(0x45, 667); // "E"
        GW.put(0x46, 611); // "F"
        GW.put(0x47, 778); // "G"
        GW.put(0x48, 722); // "H"
        GW.put(0x49, 278); // "I"
        GW.put(0x4A, 500); // "J"
        GW.put(0x4B, 667); // "K"
        GW.put(0x4C, 556); // "L"
        GW.put(0x4D, 833); // "M"
        GW.put(0x4E, 722); // "N"
        GW.put(0x4F, 778); // "O"
        GW.put(0x50, 667); // "P"
        GW.put(0x51, 778); // "Q"
        GW.put(0x52, 722); // "R"
        GW.put(0x53, 667); // "S"
        GW.put(0x54, 611); // "T"
        GW.put(0x55, 722); // "U"
        GW.put(0x56, 667); // "V"
        GW.put(0x57, 944); // "W"
        GW.put(0x58, 667); // "X"
        GW.put(0x59, 667); // "Y"
        GW.put(0x5A, 611); // "Z"
        GW.put(0x20, 278); // " "
        GW.put(0x21, 278); // "!"
        GW.put(0x22, 355); // "\""
        GW.put(0x23, 556); // "#"
        GW.put(0x24, 556); // "$"
        GW.put(0x25, 889); // "%"
        GW.put(0x26, 667); // "&"
        GW.put(0x27, 191); // "'"
        GW.put(0x28, 333); // "("
        GW.put(0x29, 333); // ")"
        GW.put(0x2A, 389); // "*"
        GW.put(0x2B, 584); // "+"
        GW.put(0x2C, 278); // ","
        GW.put(0x2D, 333); // "-"
        GW.put(0x2E, 278); // "."
        GW.put(0x2F, 278); // "/"
        GW.put(0x3A, 278); // ":"
        GW.put(0x3B, 278); // ";"
        GW.put(0x3C, 584); // "<"
        GW.put(0x3D, 584); // "="
        GW.put(0x3E, 584); // ">"
        GW.put(0x3F, 556); // "?"
        GW.put(0x40, 1015); // "@"
        GW.put(0x5B, 278); // "["
        GW.put(0x5C, 278); // "\\"
        GW.put(0x5D, 278); // "]"
        GW.put(0x5F, 556); // "_"
        GW.put(0x60, 333); // "`"
        GW.put(0x7B, 334); // "{"
        GW.put(0x7C, 260); // "|"
        GW.put(0x7D, 334); // "}"
        GW.put(0x7E, 584); // "~"
    }

    public static final class Result {
        public final String text;
        public final boolean lean;
        public final int points;

        Result(String text, boolean lean) {
            this.text = text;
            this.lean = lean;
            this.points = text.codePointCount(0, text.length());
        }
    }

    private Converter() {}

    // ---- text helpers -------------------------------------------------------

    private static String reverseText(String value) {
        BreakIterator it = BreakIterator.getCharacterInstance();
        it.setText(value);
        List<String> parts = new ArrayList<>();
        int start = it.first();
        for (int end = it.next(); end != BreakIterator.DONE; start = end, end = it.next()) {
            parts.add(value.substring(start, end));
        }
        StringBuilder sb = new StringBuilder();
        for (int i = parts.size() - 1; i >= 0; i--) sb.append(parts.get(i));
        return sb.toString();
    }

    private static int textW(String str) {
        int total = 0;
        int i = 0;
        while (i < str.length()) {
            int cp = str.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.getType(cp) == Character.FORMAT) continue;   // invisible marks have no width
            Integer w = GW.get(cp);
            if (w != null) total += w;
            else total += cp > 0x2000 ? 1000 : 556;
        }
        return total;
    }

    // ---- where chat lines can break -----------------------------------------

    /** Indexes of the words that start a new line when lines hold at most cap. */
    private static List<Integer> lineStarts(List<Integer> widths, double cap) {
        List<Integer> starts = new ArrayList<>();
        double used = -1;
        for (int i = 0; i < widths.size(); i++) {
            int w = widths.get(i);
            if (used < 0) used = w;
            else if (used + SPACE_W + w <= cap) used += SPACE_W + w;
            else { starts.add(i); used = w; }
        }
        return starts;
    }

    /**
     * Inside a group the chat lays words out in REVERSED order (the group is stored flipped),
     * so a group is safe only if, laid out that way, no line break can land inside it.
     */
    private static boolean isSafe(List<List<String>> groups) {
        List<Integer> lw = new ArrayList<>();
        boolean[] boundary;
        List<Integer> boundaryIdx = new ArrayList<>();
        int idx = 0;
        for (List<String> g : groups) {
            boundaryIdx.add(idx);
            for (int i = g.size() - 1; i >= 0; i--) { lw.add(textW(g.get(i))); idx++; }
        }
        boundary = new boolean[lw.size() + 1];
        for (int b : boundaryIdx) boundary[b] = true;

        List<Integer> lo = lineStarts(lw, CAP_LO);
        List<Integer> hi = lineStarts(lw, CAP_HI);
        for (int k = 0; k < lo.size(); k++) {
            int to = k < hi.size() ? hi.get(k) : lw.size() - 1;
            for (int j = lo.get(k); j <= to; j++) if (!boundary[j]) return false;
        }
        return true;
    }

    /** Grow each group word by word for as long as it stays safe. */
    private static List<String> groupWords(String[] words) {
        List<List<String>> groups = new ArrayList<>();
        List<String> first = new ArrayList<>();
        first.add(words[0]);
        groups.add(first);
        for (int i = 1; i < words.length; i++) {
            List<String> last = groups.get(groups.size() - 1);
            List<String> grown = new ArrayList<>(last);
            grown.add(words[i]);

            List<List<String>> trial = new ArrayList<>(groups.subList(0, groups.size() - 1));
            trial.add(grown);
            if (isSafe(trial)) {
                groups.set(groups.size() - 1, grown);
            } else {
                List<String> fresh = new ArrayList<>();
                fresh.add(words[i]);
                groups.add(fresh);
            }
        }
        List<String> out = new ArrayList<>();
        for (List<String> g : groups) out.add(String.join(" ", g));
        return out;
    }

    // ---- build the output ---------------------------------------------------

    private static String wrapGroups(List<String> groups, boolean rlo, boolean pdf, int zwjCount) {
        StringBuilder out = new StringBuilder();
        for (int n = 0; n < groups.size(); n++) {
            if (n > 0) out.append(' ');
            String text = groups.get(n);
            if (text.isEmpty()) continue;
            StringBuilder w = new StringBuilder(reverseText(text));
            for (int i = 0; i < zwjCount; i++) w.append(ZWJ);
            if (rlo) {
                out.append(LRI).append(RLO).append(w).append(pdf ? PDF : "").append(PDI);
            } else {
                out.append(w);
            }
        }
        return out.toString();
    }

    /**
     * Convert a whole message. rlo = flip it so it reads normally; zwj = add zero width joiners.
     * Extras are dropped, in order, until the result fits POINT_BUDGET.
     */
    public static Result convert(String value, boolean rlo, boolean zwj) {
        if (value == null || value.isEmpty()) return new Result("", false);
        int maxZ = zwj ? 2 : 0;
        List<String> groups = new ArrayList<>();
        if (rlo) {
            for (String g : groupWords(value.split(" ", -1))) groups.add(g);
        } else {
            groups.add(value);
            return new Result(wrapGroups(groups, false, false, maxZ), false);
        }

        // tiers: full, no PDF, then fewer ZWJ
        List<int[]> tiers = new ArrayList<>();   // {pdf, zwjCount}
        tiers.add(new int[]{1, maxZ});
        tiers.add(new int[]{0, maxZ});
        for (int z = maxZ - 1; z >= 0; z--) tiers.add(new int[]{0, z});

        String text = "";
        int idx = 0;
        for (; idx < tiers.size(); idx++) {
            int[] t = tiers.get(idx);
            text = wrapGroups(groups, true, t[0] == 1, t[1]);
            if (text.codePointCount(0, text.length()) <= POINT_BUDGET) break;
        }
        if (idx == tiers.size()) idx = tiers.size() - 1;   // leanest possible, still over budget
        return new Result(text, idx > 0);
    }
}
