package com.godfather.keyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Minimal keyboard: letters, numbers, comma, period, question mark, space, delete, enter.
 * Extra keys: clipboard history, RLO / ZWJ switches, and convert (with undo).
 */
public class GodfatherIME extends InputMethodService {

    private static final int BG = Color.BLACK;
    private static final int FG = 0xFFECEEF2;
    private static final int MUTED = 0xFF9AA3B0;
    private static final int KEY = 0xFF171B22;
    private static final int KEY_DOWN = 0xFF2B323D;
    private static final int ON = 0xFF3C5FB8;

    private static final String PREFS = "godfather";
    private static final String SEP = "\u0001";
    private static final int MAX_CLIPS = 25;

    private SharedPreferences prefs;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> clips = new ArrayList<>();

    private LinearLayout keyboardPane;
    private LinearLayout clipPane;
    private LinearLayout clipList;
    private Button rloKey;
    private Button zwjKey;
    private Button convertKey;

    // what the field held before the last convert, so convert can be undone
    private String undoOriginal;
    private String undoConverted;

    private final Runnable repeatDelete = new Runnable() {
        @Override
        public void run() {
            deleteOne();
            handler.postDelayed(this, 45);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadClips();
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {
                captureClipboard();
            }
        };
        clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (clipboard != null && clipListener != null) {
            clipboard.removePrimaryClipChangedListener(clipListener);
        }
        handler.removeCallbacks(repeatDelete);
        super.onDestroy();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        captureClipboard();
        undoOriginal = null;
        undoConverted = null;
        if (convertKey != null) convertKey.setText("convert");
        showKeyboard();
    }

    // ------------------------------------------------------------------ views

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(3), dp(4), dp(3), dp(8));

        keyboardPane = new LinearLayout(this);
        keyboardPane.setOrientation(LinearLayout.VERTICAL);
        buildKeyboard(keyboardPane);

        clipPane = new LinearLayout(this);
        clipPane.setOrientation(LinearLayout.VERTICAL);
        buildClipPane(clipPane);

        root.addView(keyboardPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(clipPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        showKeyboard();
        return root;
    }

    private void buildKeyboard(LinearLayout pane) {
        // top strip: clipboard, switches, convert
        LinearLayout top = row(38);
        Button clipKey = key("clip", 1.1f, 13);
        clipKey.setOnClickListener(v -> { tap(v); showClips(); });
        rloKey = key("RLO", 1f, 13);
        rloKey.setOnClickListener(v -> { tap(v); flip("rlo"); });
        zwjKey = key("ZWJ", 1f, 13);
        zwjKey.setOnClickListener(v -> { tap(v); flip("zwj"); });
        convertKey = key("convert", 2f, 14);
        convertKey.setOnClickListener(v -> { tap(v); convertOrUndo(); });
        top.addView(clipKey);
        top.addView(rloKey);
        top.addView(zwjKey);
        top.addView(convertKey);
        pane.addView(top);
        refreshSwitches();

        addLetterRow(pane, "1234567890", 0f, 0f);
        addLetterRow(pane, "qwertyuiop", 0f, 0f);
        addLetterRow(pane, "asdfghjkl", 0.5f, 0.5f);

        // z x c v b n m + delete
        LinearLayout r3 = row(46);
        r3.addView(spacer(0.5f));
        for (char c : "zxcvbnm".toCharArray()) r3.addView(letterKey(String.valueOf(c)));
        Button del = key("\u232B", 1.5f, 18);
        del.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    deleteOne();
                    handler.postDelayed(repeatDelete, 400);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    handler.removeCallbacks(repeatDelete);
                    return true;
                default:
                    return true;
            }
        });
        r3.addView(del);
        pane.addView(r3);

        // , space . ? enter
        LinearLayout bottom = row(46);
        bottom.addView(letterKey(","));
        Button space = key("space", 5f, 14);
        space.setOnClickListener(v -> { tap(v); typed(" "); });
        bottom.addView(space);
        bottom.addView(letterKey("."));
        bottom.addView(letterKey("?"));
        Button enter = key("\u21B5", 1.6f, 18);
        enter.setOnClickListener(v -> { tap(v); enterPressed(); });
        bottom.addView(enter);
        pane.addView(bottom);
    }

    private void addLetterRow(LinearLayout pane, String chars, float leftPad, float rightPad) {
        LinearLayout r = row(46);
        if (leftPad > 0f) r.addView(spacer(leftPad));
        for (char c : chars.toCharArray()) r.addView(letterKey(String.valueOf(c)));
        if (rightPad > 0f) r.addView(spacer(rightPad));
        pane.addView(r);
    }

    private Button letterKey(final String label) {
        Button b = key(label, 1f, 19);
        b.setOnClickListener(v -> { tap(v); typed(label); });
        return b;
    }

    private void buildClipPane(LinearLayout pane) {
        LinearLayout head = row(42);
        Button back = key("\u2190 back", 1f, 14);
        back.setOnClickListener(v -> { tap(v); showKeyboard(); });
        Button clear = key("clear all", 1f, 14);
        clear.setOnClickListener(v -> { tap(v); clips.clear(); saveClips(); rebuildClipList(); });
        head.addView(back);
        head.addView(clear);
        pane.addView(head);

        ScrollView scroll = new ScrollView(this);
        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(clipList, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pane.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46 * 4 + 6)));
    }

    private void rebuildClipList() {
        clipList.removeAllViews();
        if (clips.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Nothing copied yet. Copy some text and it shows up here.");
            empty.setTextColor(MUTED);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(dp(12), dp(16), dp(12), dp(16));
            clipList.addView(empty);
            return;
        }
        for (final String clip : new ArrayList<>(clips)) {
            Button item = new Button(this);
            item.setAllCaps(false);
            item.setText(clip);
            item.setMaxLines(2);
            item.setEllipsize(TextUtils.TruncateAt.END);
            item.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            item.setTextColor(FG);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setStateListAnimator(null);
            item.setBackground(keyBackground(KEY));
            item.setPadding(dp(12), dp(6), dp(12), dp(6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            item.setLayoutParams(lp);
            item.setOnClickListener(v -> { tap(v); typed(clip); showKeyboard(); });
            item.setOnLongClickListener(v -> {
                clips.remove(clip);
                saveClips();
                rebuildClipList();
                return true;
            });
            clipList.addView(item);
        }
    }

    // ------------------------------------------------------------------ view helpers

    private LinearLayout row(int heightDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp)));
        return r;
    }

    private View spacer(float weight) {
        View s = new View(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
        return s;
    }

    private Button key(String label, float weight, int sp) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(FG);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        b.setBackground(keyBackground(KEY));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private StateListDrawable keyBackground(int color) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, shape(KEY_DOWN));
        states.addState(new int[]{}, shape(color));
        return states;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void tap(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void showKeyboard() {
        if (keyboardPane == null || clipPane == null) return;
        keyboardPane.setVisibility(View.VISIBLE);
        clipPane.setVisibility(View.GONE);
    }

    private void showClips() {
        captureClipboard();
        rebuildClipList();
        keyboardPane.setVisibility(View.GONE);
        clipPane.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ switches

    private void flip(String name) {
        prefs.edit().putBoolean(name, !prefs.getBoolean(name, true)).apply();
        refreshSwitches();
    }

    private void refreshSwitches() {
        if (rloKey != null) rloKey.setBackground(keyBackground(prefs.getBoolean("rlo", true) ? ON : KEY));
        if (zwjKey != null) zwjKey.setBackground(keyBackground(prefs.getBoolean("zwj", true) ? ON : KEY));
    }

    // ------------------------------------------------------------------ typing

    private void typed(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        forgetUndo();
    }

    private void deleteOne() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence selected = ic.getSelectedText(0);
        if (selected != null && selected.length() > 0) ic.commitText("", 1);
        else ic.deleteSurroundingText(1, 0);
        forgetUndo();
    }

    private void enterPressed() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;
        if (info != null && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    private void forgetUndo() {
        if (undoConverted != null) {
            undoOriginal = null;
            undoConverted = null;
            if (convertKey != null) convertKey.setText("convert");
        }
    }

    // ------------------------------------------------------------------ convert

    private void convertOrUndo() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(20000, 0);
        CharSequence after = ic.getTextAfterCursor(20000, 0);
        String b = before == null ? "" : before.toString();
        String a = after == null ? "" : after.toString();
        String all = b + a;

        if (undoConverted != null && all.equals(undoConverted)) {
            replaceAll(ic, b, a, undoOriginal);
            undoOriginal = null;
            undoConverted = null;
            convertKey.setText("convert");
            return;
        }
        if (all.isEmpty()) return;

        Converter.Result result = Converter.convert(
                all, prefs.getBoolean("rlo", true), prefs.getBoolean("zwj", true));
        replaceAll(ic, b, a, result.text);
        undoOriginal = all;
        undoConverted = result.text;
        convertKey.setText("undo \u00B7 " + result.points);
    }

    private void replaceAll(InputConnection ic, String before, String after, String text) {
        ic.beginBatchEdit();
        ic.deleteSurroundingText(before.length(), after.length());
        ic.commitText(text, 1);
        ic.endBatchEdit();
    }

    // ------------------------------------------------------------------ clipboard history

    private void captureClipboard() {
        try {
            ClipData data = clipboard.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return;
            CharSequence text = data.getItemAt(0).coerceToText(this);
            if (text == null) return;
            String s = text.toString();
            if (s.trim().isEmpty()) return;
            addClip(s.replace(SEP, " "));
        } catch (Exception ignored) {
            // clipboard can be unreadable at times; nothing to do
        }
    }

    private void addClip(String s) {
        clips.remove(s);
        clips.add(0, s);
        while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
        saveClips();
    }

    private void loadClips() {
        clips.clear();
        String raw = prefs.getString("clips", "");
        if (raw == null || raw.isEmpty()) return;
        for (String s : raw.split(SEP)) if (!s.isEmpty()) clips.add(s);
    }

    private void saveClips() {
        prefs.edit().putString("clips", TextUtils.join(SEP, clips)).apply();
    }
}
