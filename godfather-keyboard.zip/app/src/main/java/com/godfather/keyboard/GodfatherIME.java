package com.godfather.keyboard;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Minimal keyboard: letters, numbers, comma, period, question mark, space, delete, enter.
 * Extra keys: clipboard history, RLO / ZWJ switches, and convert (with undo) that shows its
 * point count live while you type.
 */
public class GodfatherIME extends InputMethodService {

    // ---- look: dark, Samsung-style spacing -------------------------------------------------
    private static final int BG = Color.BLACK;
    private static final int FG = 0xFFECEEF2;
    private static final int MUTED = 0xFF9AA3B0;
    private static final int KEY = 0xFF1F242C;        // letter keys
    private static final int FUNC = 0xFF2B313B;       // function keys
    private static final int KEY_DOWN = 0xFF4A5462;
    private static final int ON = 0xFF3C5FB8;
    private static final int RED = 0xFFFF6B6B;

    private static final int GAP_X = 3;               // dp each side of a key  -> 6dp between keys
    private static final int GAP_Y = 3;               // dp above and below     -> 6dp between rows

    private static final String PREFS = "godfather";
    private static final String SEP = "\u0001";
    private static final int MAX_CLIPS = 25;
    private static final int MAX_PREVIEW = 600;       // longer text is not converted or previewed

    private SharedPreferences prefs;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> clips = new ArrayList<>();
    private String blockedClip;                       // a clip the user removed; do not re-add it on sync

    private LinearLayout keyboardPane;
    private LinearLayout clipPane;
    private LinearLayout clipList;
    private KeyView rloKey;
    private KeyView zwjKey;
    private KeyView convertKey;

    // what the field held before the last convert, so convert can be undone
    private String undoOriginal;
    private String undoConverted;
    private String lastPreview = "";

    private final Runnable refreshPoints = new Runnable() {
        @Override
        public void run() {
            updatePointsNow();
        }
    };

    private final Runnable repeatDelete = new Runnable() {
        @Override
        public void run() {
            deleteOne();
            handler.postDelayed(this, 40);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadClips();
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {
                captureClipboard(true);
            }
        };
        clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (clipboard != null && clipListener != null) {
            clipboard.removePrimaryClipChangedListener(clipListener);
        }
        handler.removeCallbacks(repeatDelete);
        handler.removeCallbacks(refreshPoints);
        super.onDestroy();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        askForHighRefreshRate();
        captureClipboard(false);
        undoOriginal = null;
        undoConverted = null;
        lastPreview = "";
        setConvertLabel("convert", false);
        showKeyboard();
        schedulePoints();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        schedulePoints();   // text changed from outside (paste, sent message, cursor move)
    }

    /** Ask the display for its top refresh rate while the keyboard is up (smoother key feedback). */
    private void askForHighRefreshRate() {
        try {
            Dialog dialog = getWindow();
            if (dialog == null) return;
            Window w = dialog.getWindow();
            if (w == null) return;
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.preferredRefreshRate = 120f;
            w.setAttributes(lp);
        } catch (Exception ignored) {
            // not supported on this device; the keyboard still works
        }
    }

    // ------------------------------------------------------------------ views

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(4), dp(6), dp(4), dp(12));

        keyboardPane = new LinearLayout(this);
        keyboardPane.setOrientation(LinearLayout.VERTICAL);
        buildKeyboard(keyboardPane);

        clipPane = new LinearLayout(this);
        clipPane.setOrientation(LinearLayout.VERTICAL);
        buildClipPane(clipPane);

        root.addView(keyboardPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(clipPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        showKeyboard();
        return root;
    }

    private void buildKeyboard(LinearLayout pane) {
        // top strip: clipboard, switches, convert (shows its points live)
        LinearLayout top = row(40);
        KeyView clipKey = key("clip", 1.1f, 13, FUNC, false);
        clipKey.setAction(this::showClips);
        rloKey = key("RLO", 1f, 13, FUNC, false);
        rloKey.setAction(() -> flip("rlo"));
        zwjKey = key("ZWJ", 1f, 13, FUNC, false);
        zwjKey.setAction(() -> flip("zwj"));
        convertKey = key("convert", 2.6f, 14, FUNC, false);
        convertKey.setAction(this::convertOrUndo);
        top.addView(clipKey);
        top.addView(rloKey);
        top.addView(zwjKey);
        top.addView(convertKey);
        pane.addView(top);
        refreshSwitches();

        addKeyRow(pane, "1234567890", 0f, 0f, 44, 17, KEY);
        addKeyRow(pane, "qwertyuiop", 0f, 0f, 52, 21, KEY);
        addKeyRow(pane, "asdfghjkl", 0.5f, 0.5f, 52, 21, KEY);

        // z x c v b n m + delete
        LinearLayout r3 = row(52);
        r3.addView(spacer(0.5f));
        for (char c : "zxcvbnm".toCharArray()) r3.addView(typingKey(String.valueOf(c), 21, KEY));
        KeyView del = key("\u232B", 1.5f, 19, FUNC, true);
        del.setAction(() -> {
            deleteOne();
            handler.postDelayed(repeatDelete, 380);
        });
        del.setOnRelease(() -> handler.removeCallbacks(repeatDelete));
        r3.addView(del);
        pane.addView(r3);

        // , space . ? enter
        LinearLayout bottom = row(52);
        bottom.addView(typingKey(",", 21, FUNC));
        KeyView space = key("space", 5f, 14, KEY, true);
        space.setAction(() -> typed(" "));
        bottom.addView(space);
        bottom.addView(typingKey(".", 21, FUNC));
        bottom.addView(typingKey("?", 21, FUNC));
        KeyView enter = key("\u21B5", 1.6f, 19, FUNC, true);
        enter.setAction(this::enterPressed);
        bottom.addView(enter);
        pane.addView(bottom);
    }

    private void addKeyRow(LinearLayout pane, String chars, float leftPad, float rightPad,
                           int heightDp, int sp, int color) {
        LinearLayout r = row(heightDp);
        if (leftPad > 0f) r.addView(spacer(leftPad));
        for (char c : chars.toCharArray()) r.addView(typingKey(String.valueOf(c), sp, color));
        if (rightPad > 0f) r.addView(spacer(rightPad));
        pane.addView(r);
    }

    private KeyView typingKey(final String label, int sp, int color) {
        KeyView k = key(label, 1f, sp, color, true);
        k.setAction(() -> typed(label));
        return k;
    }

    private void buildClipPane(LinearLayout pane) {
        LinearLayout head = row(46);
        KeyView back = key("\u2190 back", 1f, 14, FUNC, false);
        back.setAction(this::showKeyboard);
        KeyView clear = key("clear all", 1f, 14, FUNC, false);
        clear.setAction(this::clearAllClips);
        head.addView(back);
        head.addView(clear);
        pane.addView(head);

        ScrollView scroll = new ScrollView(this);
        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(clipList, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pane.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(240)));
    }

    private void rebuildClipList() {
        clipList.removeAllViews();
        if (clips.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Nothing copied yet. Copy some text and it shows up here.");
            empty.setTextColor(MUTED);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(dp(12), dp(16), dp(12), dp(16));
            clipList.addView(empty);
            return;
        }
        for (final String clip : new ArrayList<>(clips)) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lineLp.setMargins(dp(GAP_X), dp(GAP_Y), dp(GAP_X), dp(GAP_Y));
            line.setLayoutParams(lineLp);

            TextView text = new TextView(this);
            text.setText(clip);
            text.setMaxLines(2);
            text.setEllipsize(TextUtils.TruncateAt.END);
            text.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            text.setTextColor(FG);
            text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            text.setPadding(dp(12), dp(4), dp(12), dp(4));
            text.setBackground(listBackground(KEY));
            text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            text.setOnClickListener(v -> { typed(clip); showKeyboard(); });

            TextView remove = new TextView(this);
            remove.setText("\u2715");
            remove.setGravity(Gravity.CENTER);
            remove.setTextColor(MUTED);
            remove.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            remove.setBackground(listBackground(FUNC));
            LinearLayout.LayoutParams rm = new LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT);
            rm.setMargins(dp(6), 0, 0, 0);
            remove.setLayoutParams(rm);
            remove.setOnClickListener(v -> removeClip(clip));

            line.addView(text);
            line.addView(remove);
            clipList.addView(line);
        }
    }

    // ------------------------------------------------------------------ view helpers

    private LinearLayout row(int heightDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp)));
        return r;
    }

    private View spacer(float weight) {
        View s = new View(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
        return s;
    }

    private KeyView key(String label, float weight, int sp, int color, boolean fireOnDown) {
        KeyView k = new KeyView(this, label, sp, color, FG, KEY_DOWN, dp(10), fireOnDown);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(GAP_X), dp(GAP_Y), dp(GAP_X), dp(GAP_Y));
        k.setLayoutParams(lp);
        return k;
    }

    private StateListDrawable listBackground(int color) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, shape(KEY_DOWN));
        states.addState(new int[]{}, shape(color));
        return states;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void showKeyboard() {
        if (keyboardPane == null || clipPane == null) return;
        keyboardPane.setVisibility(View.VISIBLE);
        clipPane.setVisibility(View.GONE);
    }

    private void showClips() {
        captureClipboard(false);
        rebuildClipList();
        keyboardPane.setVisibility(View.GONE);
        clipPane.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ switches

    private void flip(String name) {
        prefs.edit().putBoolean(name, !prefs.getBoolean(name, true)).apply();
        refreshSwitches();
        lastPreview = "";
        schedulePoints();
    }

    private void refreshSwitches() {
        if (rloKey != null) rloKey.setColor(prefs.getBoolean("rlo", true) ? ON : FUNC);
        if (zwjKey != null) zwjKey.setColor(prefs.getBoolean("zwj", true) ? ON : FUNC);
    }

    // ------------------------------------------------------------------ typing

    private void typed(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        forgetUndo();
        schedulePoints();
    }

    private void deleteOne() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence selected = ic.getSelectedText(0);
        if (selected != null && selected.length() > 0) ic.commitText("", 1);
        else ic.deleteSurroundingText(1, 0);
        forgetUndo();
        schedulePoints();
    }

    private void enterPressed() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;
        if (info != null && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    private void forgetUndo() {
        if (undoConverted != null) {
            undoOriginal = null;
            undoConverted = null;
            setConvertLabel("convert", false);
        }
    }

    // ------------------------------------------------------------------ convert + live points

    private String fieldText(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(MAX_PREVIEW + 1, 0);
        CharSequence after = ic.getTextAfterCursor(MAX_PREVIEW + 1, 0);
        return (before == null ? "" : before.toString()) + (after == null ? "" : after.toString());
    }

    private void convertOrUndo() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(MAX_PREVIEW + 1, 0);
        CharSequence after = ic.getTextAfterCursor(MAX_PREVIEW + 1, 0);
        String b = before == null ? "" : before.toString();
        String a = after == null ? "" : after.toString();
        String all = b + a;

        if (undoConverted != null && all.equals(undoConverted)) {
            replaceAll(ic, b, a, undoOriginal);
            undoOriginal = null;
            undoConverted = null;
            lastPreview = "";
            setConvertLabel("convert", false);
            schedulePoints();
            return;
        }
        if (all.isEmpty() || all.length() > MAX_PREVIEW) return;

        Converter.Result result = Converter.convert(
                all, prefs.getBoolean("rlo", true), prefs.getBoolean("zwj", true));
        replaceAll(ic, b, a, result.text);
        undoOriginal = all;
        undoConverted = result.text;
        setConvertLabel("undo \u00B7 " + result.points, result.points > Converter.POINT_BUDGET);
    }

    private void replaceAll(InputConnection ic, String before, String after, String text) {
        ic.beginBatchEdit();
        ic.deleteSurroundingText(before.length(), after.length());
        ic.commitText(text, 1);
        ic.endBatchEdit();
    }

    /** Re-count shortly after the text changes, so typing itself is never held up. */
    private void schedulePoints() {
        handler.removeCallbacks(refreshPoints);
        handler.postDelayed(refreshPoints, 120);
    }

    /** Shows the point count the current text will have, before convert is tapped. */
    private void updatePointsNow() {
        if (convertKey == null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            setConvertLabel("convert", false);
            return;
        }
        String all = fieldText(ic);

        if (undoConverted != null && all.equals(undoConverted)) {
            int pts = undoConverted.codePointCount(0, undoConverted.length());
            setConvertLabel("undo \u00B7 " + pts, pts > Converter.POINT_BUDGET);
            return;
        }
        boolean rlo = prefs.getBoolean("rlo", true);
        boolean zwj = prefs.getBoolean("zwj", true);
        String key = rlo + "|" + zwj + "|" + all;
        if (key.equals(lastPreview)) return;       // nothing changed since the last count
        lastPreview = key;

        if (all.isEmpty()) {
            setConvertLabel("convert", false);
            return;
        }
        if (all.length() > MAX_PREVIEW) {
            setConvertLabel("too long", true);
            return;
        }
        Converter.Result r = Converter.convert(all, rlo, zwj);
        setConvertLabel("convert \u00B7 " + r.points + "/" + Converter.POINT_BUDGET,
                r.points > Converter.POINT_BUDGET);
    }

    private void setConvertLabel(String text, boolean over) {
        if (convertKey == null) return;
        convertKey.setLabel(text);
        convertKey.setTextTint(over ? RED : FG);
    }

    // ------------------------------------------------------------------ clipboard history

    private String currentClipboardText() {
        try {
            ClipData data = clipboard.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return null;
            CharSequence text = data.getItemAt(0).coerceToText(this);
            if (text == null) return null;
            String s = text.toString();
            if (s.trim().isEmpty()) return null;
            return s.replace(SEP, " ");
        } catch (Exception e) {
            return null;     // clipboard can be unreadable at times
        }
    }

    /** fromCopy = a real copy just happened. Otherwise this is only a sync, which must not revive removed clips. */
    private void captureClipboard(boolean fromCopy) {
        String s = currentClipboardText();
        if (s == null) return;
        if (fromCopy) blockedClip = null;
        else if (s.equals(blockedClip)) return;
        addClip(s);
    }

    private void removeClip(String s) {
        clips.remove(s);
        saveClips();
        if (s.equals(currentClipboardText())) {
            blockedClip = s;
            clearSystemClipboard();
        }
        rebuildClipList();
    }

    private void clearAllClips() {
        clips.clear();
        saveClips();
        blockedClip = currentClipboardText();
        clearSystemClipboard();
        rebuildClipList();
    }

    private void clearSystemClipboard() {
        try {
            if (Build.VERSION.SDK_INT >= 28) clipboard.clearPrimaryClip();
            else clipboard.setPrimaryClip(ClipData.newPlainText("", ""));
        } catch (Exception ignored) {
            // if it cannot be cleared, blockedClip still keeps it from coming back
        }
    }

    private void addClip(String s) {
        clips.remove(s);
        clips.add(0, s);
        while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
        saveClips();
    }

    private void loadClips() {
        clips.clear();
        String raw = prefs.getString("clips", "");
        if (raw == null || raw.isEmpty()) return;
        for (String s : raw.split(SEP)) if (!s.isEmpty()) clips.add(s);
    }

    private void saveClips() {
        prefs.edit().putString("clips", TextUtils.join(SEP, clips)).apply();
    }
}
