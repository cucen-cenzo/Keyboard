package com.godfather.keyboard;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Minimal keyboard: letters, numbers, comma, period, question mark, space, delete, enter.
 * Top strip: clipboard history, RLO / ZWJ / AUTO switches and a live status pill (points + chars).
 * AUTO converts the message by itself: when typing pauses, and right before enter sends it.
 */
public class GodfatherIME extends InputMethodService {

    // ---- look: copied from a real Samsung keyboard screenshot (1080 px wide) --------------------
    // Every size below is in "design px" on a 1080 px wide screen and is scaled to the real screen.
    //   keys: 88 px wide (letters), 96 px tall (numbers) / 116 px tall (letters), 17 px gap sideways,
    //   34 px gap between rows, row 3 inset by half a key, space bar centred.
    private static final int BG = Color.BLACK;
    private static final int FG = 0xFFF2F2F2;
    private static final int MUTED = 0xFF9A9AA0;
    private static final int KEY = 0xFF3A3A3C;        // letter, number, comma, period, space
    private static final int FUNC = 0xFF18181A;       // shift, delete, enter, ? and the top strip
    private static final int KEY_DOWN = 0xFF5E5E63;
    private static final int FUNC_DOWN = 0xFF3A3A3C;
    private static final int ON = 0xFF3C5FB8;
    private static final int RED = 0xFFFF6B6B;
    private static final int MINT = 0xFF5BE3A0;       // healthy / switched on
    private static final int AMBER = 0xFFFFC857;      // getting close to the limit
    private static final int CHIP_ON = 0xFF1B2A4F;    // deep blue fill for a switched-on chip
    private static final int CHIP_LINE = 0xFF5B8CFF;  // soft blue outline for a switched-on chip
    private static final int DOT_OFF = 0xFF55555A;

    private static final long AUTO_DELAY_MS = 700;    // how long typing must pause before auto-convert

    private static final String PREFS = "godfather";
    private static final String SEP = "\u0001";
    private static final int MAX_CLIPS = 25;
    private static final int MAX_PREVIEW = 600;       // longer text is not converted or previewed

    private SharedPreferences prefs;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> clips = new ArrayList<>();
    private String blockedClip;                       // a clip the user removed; do not re-add it on sync

    private LinearLayout keyboardPane;
    private LinearLayout clipPane;
    private LinearLayout clipList;
    private float scale = 1f;
    private KeyboardLayout keyboardRoot;
    private KeyView rloKey;
    private KeyView zwjKey;
    private KeyView statusKey;
    private KeyView autoKey;

    // shift: 0 = off, 1 = next letter only, 2 = caps lock
    private int shiftState = 0;
    private long lastShiftTap = 0;
    private KeyView shiftKey;
    private final List<KeyView> letterViews = new ArrayList<>();
    private final List<String> letterBase = new ArrayList<>();

    // what the field held before the last convert, so convert can be undone
    private String undoOriginal;
    private String undoConverted;
    private String lastPreview = "";

    // The keyboard keeps its own copy of what it typed, so counting points never waits on the app.
    // The real text is only read once, after you pause typing.
    private String shadow = "";
    private boolean shadowKnown = false;
    private int selStart = 0;
    private int selEnd = 0;

    private final Runnable refreshPoints = new Runnable() {
        @Override
        public void run() {
            updatePointsNow();
        }
    };

    private final Runnable autoConvert = new Runnable() {
        @Override
        public void run() {
            autoConvertNow();
        }
    };

    private final Runnable reconcile = new Runnable() {
        @Override
        public void run() {
            reconcileNow();
        }
    };

    private final Runnable repeatDelete = new Runnable() {
        @Override
        public void run() {
            deleteOne();
            handler.postDelayed(this, 40);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadClips();
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {
                captureClipboard(true);
            }
        };
        clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (clipboard != null && clipListener != null) {
            clipboard.removePrimaryClipChangedListener(clipListener);
        }
        handler.removeCallbacks(repeatDelete);
        handler.removeCallbacks(refreshPoints);
        handler.removeCallbacks(reconcile);
        handler.removeCallbacks(autoConvert);
        super.onDestroy();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        askForHighRefreshRate();
        captureClipboard(false);
        handler.removeCallbacks(autoConvert);
        undoOriginal = null;
        undoConverted = null;
        lastPreview = "";
        shiftState = 0;
        refreshShift();
        shadow = "";
        shadowKnown = false;
        showKeyboard();
        scheduleReconcile(150);
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        selStart = newSelStart;
        selEnd = newSelEnd;
        scheduleReconcile(450);   // text may have changed from outside (paste, sent message)
    }

    /** Ask the display for its top refresh rate while the keyboard is up (smoother key feedback). */
    private void askForHighRefreshRate() {
        try {
            Dialog dialog = getWindow();
            if (dialog == null) return;
            Window w = dialog.getWindow();
            if (w == null) return;
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.preferredRefreshRate = 120f;
            w.setAttributes(lp);
        } catch (Exception ignored) {
            // not supported on this device; the keyboard still works
        }
    }

    // ------------------------------------------------------------------ views

    @Override
    public View onCreateInputView() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        scale = Math.min(dm.widthPixels, dm.heightPixels) / 1080f;   // same key size in landscape

        KeyboardLayout root = new KeyboardLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(u(14.5f), 0, u(14.5f), u(24));

        letterViews.clear();
        letterBase.clear();

        keyboardPane = new LinearLayout(this);
        keyboardPane.setOrientation(LinearLayout.VERTICAL);
        buildKeyboard(keyboardPane);

        clipPane = new LinearLayout(this);
        clipPane.setOrientation(LinearLayout.VERTICAL);
        buildClipPane(clipPane);

        root.addView(keyboardPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(clipPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setKeyPane(keyboardPane);
        root.setMaxReach(u(220));                    // a touch this far from every key is ignored
        root.setBubbleSizes(u(24), u(24), u(8));     // popup bubble above the pressed key
        keyboardRoot = root;
        showKeyboard();
        return root;
    }

    private void buildKeyboard(LinearLayout pane) {
        // top strip: clipboard, three switches, and the live status pill (points + chars)
        LinearLayout top = row(130);
        KeyView clipKey = pill("", 0.95f, 38);
        clipKey.setIcon(KeyView.Icon.CLIP);
        clipKey.setContentDescription("clipboard");
        clipKey.setAction(this::showClips);
        rloKey = pill("RLO", 1.15f, 36);
        rloKey.setAction(() -> flip("rlo"));
        zwjKey = pill("ZWJ", 1.15f, 36);
        zwjKey.setAction(() -> flip("zwj"));
        autoKey = pill("AUTO", 1.3f, 36);
        autoKey.setAction(() -> flip("auto"));
        statusKey = pill("0/" + Converter.POINT_BUDGET + " pts", 3.0f, 38);
        statusKey.setSubLabel("0 chars");
        statusKey.setProgress(0f, MINT);
        statusKey.setAction(this::toggleConvert);
        top.addView(clipKey);
        top.addView(rloKey);
        top.addView(zwjKey);
        top.addView(autoKey);
        top.addView(statusKey);
        pane.addView(top);
        refreshSwitches();

        // numbers: shorter keys (96 px) like Samsung
        LinearLayout nums = row(130);
        for (char c : "1234567890".toCharArray()) nums.addView(typingKey(String.valueOf(c), 56, KEY));
        pane.addView(nums);

        // q w e r t y u i o p
        LinearLayout r1 = row(150);
        for (char c : "qwertyuiop".toCharArray()) r1.addView(letterKey(String.valueOf(c)));
        pane.addView(r1);

        // a s d f g h j k l  (inset by half a key each side)
        LinearLayout r2 = row(150);
        r2.addView(spacer(0.5f));
        for (char c : "asdfghjkl".toCharArray()) r2.addView(letterKey(String.valueOf(c)));
        r2.addView(spacer(0.5f));
        pane.addView(r2);

        // shift  z x c v b n m  delete
        LinearLayout r3 = row(150);
        shiftKey = key("", 1.352f, 40, FUNC, false);
        shiftKey.setIcon(KeyView.Icon.SHIFT);
        shiftKey.setContentDescription("shift");
        shiftKey.setAction(this::onShiftTap);
        r3.addView(shiftKey);
        r3.addView(spacer(0.143f));
        for (char c : "zxcvbnm".toCharArray()) r3.addView(letterKey(String.valueOf(c)));
        r3.addView(spacer(0.15f));
        KeyView del = key("", 1.352f, 40, FUNC, true);
        del.setIcon(KeyView.Icon.BACKSPACE);
        del.setContentDescription("delete");
        del.setAction(() -> {
            deleteOne();
            handler.postDelayed(repeatDelete, 380);
        });
        del.setOnRelease(() -> handler.removeCallbacks(repeatDelete));
        r3.addView(del);
        pane.addView(r3);

        // ?  ,  [ space, centred ]  .  enter
        LinearLayout bottom = row(150);
        KeyView question = typingKey("?", 56, FUNC, 1.5f);
        bottom.addView(question);
        bottom.addView(typingKey(",", 66, KEY));
        KeyView space = key("godfather", 5f, 34, KEY, false);
        space.setTextTint(MUTED);
        space.setAction(() -> typed(" "));
        bottom.addView(space);
        bottom.addView(typingKey(".", 66, KEY));
        KeyView enter = key("", 1.5f, 40, FUNC, false);
        enter.setIcon(KeyView.Icon.ENTER);
        enter.setContentDescription("enter");
        enter.setAction(this::enterPressed);
        bottom.addView(enter);
        pane.addView(bottom);
    }

    private KeyView typingKey(final String label, float textPx, int color) {
        return typingKey(label, textPx, color, 1f);
    }

    private KeyView typingKey(final String label, float textPx, int color, float weight) {
        KeyView k = key(label, weight, textPx, color, false);
        k.setPreview(true);
        k.setAction(() -> typed(label));
        return k;
    }

    /** A letter key: shows a capital when shift is on, and types it. */
    private KeyView letterKey(final String base) {
        KeyView k = key(base, 1f, 66, KEY, false);
        k.setPreview(true);
        k.setAction(() -> typedLetter(base));
        letterViews.add(k);
        letterBase.add(base);
        return k;
    }

    private void buildClipPane(LinearLayout pane) {
        LinearLayout head = row(130);
        KeyView back = key("\u2190 back", 1f, 42, FUNC, false);
        back.setAction(this::showKeyboard);
        KeyView clear = key("clear all", 1f, 42, FUNC, false);
        clear.setAction(this::clearAllClips);
        head.addView(back);
        head.addView(clear);
        pane.addView(head);

        ScrollView scroll = new ScrollView(this);
        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(clipList, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pane.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, u(600)));
    }

    private void rebuildClipList() {
        clipList.removeAllViews();
        if (clips.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Nothing copied yet. Copy some text and it shows up here.");
            empty.setTextColor(MUTED);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(40));
            empty.setPadding(u(30), u(40), u(30), u(40));
            clipList.addView(empty);
            return;
        }
        for (final String clip : new ArrayList<>(clips)) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, u(130));
            lineLp.setMargins(sideLeft(), u(17), sideRight(), u(17));
            line.setLayoutParams(lineLp);

            TextView text = new TextView(this);
            text.setText(clip);
            text.setMaxLines(2);
            text.setEllipsize(TextUtils.TruncateAt.END);
            text.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            text.setTextColor(FG);
            text.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(40));
            text.setPadding(u(30), u(8), u(30), u(8));
            text.setBackground(listBackground(KEY, KEY_DOWN));
            text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            text.setOnClickListener(v -> { typed(clip); showKeyboard(); });

            TextView remove = new TextView(this);
            remove.setText("\u2715");
            remove.setGravity(Gravity.CENTER);
            remove.setTextColor(MUTED);
            remove.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(48));
            remove.setBackground(listBackground(FUNC, FUNC_DOWN));
            LinearLayout.LayoutParams rm = new LinearLayout.LayoutParams(u(125), ViewGroup.LayoutParams.MATCH_PARENT);
            rm.setMargins(u(17), 0, 0, 0);
            remove.setLayoutParams(rm);
            remove.setOnClickListener(v -> removeClip(clip));

            line.addView(text);
            line.addView(remove);
            clipList.addView(line);
        }
    }

    // ------------------------------------------------------------------ view helpers

    /** Design px (on a 1080 px wide screen) to real pixels. */
    private int u(float designPx) {
        return Math.round(designPx * scale);
    }

    // half of the 17 px side gap on each side of a key (8 + 9, so neighbours are exactly 17 apart)
    private int sideLeft() {
        return (int) Math.floor(8.5f * scale);
    }

    private int sideRight() {
        return (int) Math.ceil(8.5f * scale);
    }

    private LinearLayout row(int designHeight) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, u(designHeight)));
        return r;
    }

    private View spacer(float weight) {
        View s = new View(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
        return s;
    }

    private KeyView key(String label, float weight, float textPx, int color, boolean fireOnDown) {
        int pressed = color == FUNC ? FUNC_DOWN : KEY_DOWN;
        KeyView k = new KeyView(this, label, u(textPx), color, FG, pressed, u(16), fireOnDown);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(sideLeft(), u(17), sideRight(), u(17));   // 17 px sideways, 34 px between rows
        k.setLayoutParams(lp);
        return k;
    }

    /** A rounded pill for the top strip (full-height corners, bold text). */
    private KeyView pill(String label, float weight, float textPx) {
        KeyView k = new KeyView(this, label, u(textPx), FUNC, FG, FUNC_DOWN, u(48), false);
        k.setBold(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(sideLeft(), u(17), sideRight(), u(17));
        k.setLayoutParams(lp);
        return k;
    }

    private StateListDrawable listBackground(int color, int pressed) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, shape(pressed));
        states.addState(new int[]{}, shape(color));
        return states;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(u(16));
        return g;
    }

    private void showKeyboard() {
        if (keyboardPane == null || clipPane == null) return;
        if (keyboardRoot != null) keyboardRoot.cancelAll();
        keyboardPane.setVisibility(View.VISIBLE);
        clipPane.setVisibility(View.GONE);
    }

    private void showClips() {
        captureClipboard(false);
        rebuildClipList();
        if (keyboardRoot != null) keyboardRoot.cancelAll();
        keyboardPane.setVisibility(View.GONE);
        clipPane.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ switches

    private boolean rloOn() {
        return prefs.getBoolean("rlo", true);
    }

    private boolean zwjOn() {
        return prefs.getBoolean("zwj", true);
    }

    private boolean autoOn() {
        return prefs.getBoolean("auto", true);
    }

    private void flip(String name) {
        prefs.edit().putBoolean(name, !prefs.getBoolean(name, true)).apply();
        refreshSwitches();
        handler.removeCallbacks(autoConvert);
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && undoConverted != null) restorePlain(ic);   // output depends on the switches: start again from plain text
        lastPreview = "";
        schedulePoints();
        scheduleAuto();
    }

    private void refreshSwitches() {
        styleChip(rloKey, rloOn());
        styleChip(zwjKey, zwjOn());
        styleChip(autoKey, autoOn());
    }

    private void styleChip(KeyView k, boolean on) {
        if (k == null) return;
        k.setColor(on ? CHIP_ON : FUNC);
        k.setTextTint(on ? FG : MUTED);
        k.setOutline(on ? CHIP_LINE : 0);
        k.setDot(on ? MINT : DOT_OFF);
    }

    // ------------------------------------------------------------------ shift

    private void onShiftTap() {
        long now = SystemClock.uptimeMillis();
        if (shiftState == 0) shiftState = 1;
        else if (shiftState == 1 && now - lastShiftTap < 450) shiftState = 2;   // double tap = caps lock
        else shiftState = 0;
        lastShiftTap = now;
        refreshShift();
    }

    private void refreshShift() {
        boolean up = shiftState != 0;
        for (int i = 0; i < letterViews.size(); i++) {
            String base = letterBase.get(i);
            letterViews.get(i).setLabel(up ? base.toUpperCase(Locale.ROOT) : base);
        }
        if (shiftKey != null) {
            shiftKey.setIcon(shiftState == 0 ? KeyView.Icon.SHIFT
                    : shiftState == 1 ? KeyView.Icon.SHIFT_ON : KeyView.Icon.SHIFT_LOCK);
        }
    }

    private void typedLetter(String base) {
        typed(shiftState != 0 ? base.toUpperCase(Locale.ROOT) : base);
        if (shiftState == 1) {          // one-shot shift ends after a letter
            shiftState = 0;
            refreshShift();
        }
    }

    // ------------------------------------------------------------------ typing

    private void typed(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (undoConverted != null) restorePlain(ic);   // the field holds the converted copy: go back to plain text first
        ic.commitText(s, 1);
        if (selStart != selEnd) shadowKnown = false;     // typed over a selection: real text unknown
        else if (shadowKnown) shadow = shadow + s;
        selStart = selEnd = selStart + s.length();
        schedulePoints();
        scheduleReconcile(450);
        scheduleAuto();
    }

    private void deleteOne() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (undoConverted != null) restorePlain(ic);
        if (selStart != selEnd) {            // a selection exists: delete it
            ic.commitText("", 1);
            shadowKnown = false;
            selEnd = selStart;
        } else {
            ic.deleteSurroundingText(1, 0);
            if (shadowKnown && !shadow.isEmpty()) {
                int cut = shadow.offsetByCodePoints(shadow.length(), -1);
                shadow = shadow.substring(0, cut);
            }
            if (selStart > 0) selStart = selEnd = selStart - 1;
        }
        schedulePoints();
        scheduleReconcile(450);
        scheduleAuto();
    }

    private void enterPressed() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;

        int action = -1;
        if (info != null && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int a = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) action = a;
        }
        if (action < 0) {                    // plain new line (multi-line box)
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
            return;
        }

        boolean sends = action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_GO
                || action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_DONE;
        handler.removeCallbacks(autoConvert);
        boolean converted = false;
        if (sends && autoOn() && undoConverted == null) {
            if (!shadowKnown) {
                shadow = fieldText(ic);
                shadowKnown = true;
            }
            converted = convertNow(ic, shadow);      // convert right before sending
        }
        final int act = action;
        if (converted) {
            // let the app apply the converted text first, then send
            handler.postDelayed(() -> {
                InputConnection again = getCurrentInputConnection();
                if (again != null) again.performEditorAction(act);
            }, 60);
        } else {
            ic.performEditorAction(action);
        }
    }

    // ------------------------------------------------------------------ convert

    private String fieldText(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(MAX_PREVIEW + 1, 0);
        CharSequence after = ic.getTextAfterCursor(MAX_PREVIEW + 1, 0);
        return (before == null ? "" : before.toString()) + (after == null ? "" : after.toString());
    }

    /** Replace everything in the field without reading it first. */
    private void replaceAllBlind(InputConnection ic, String text) {
        ic.beginBatchEdit();
        if (selStart != selEnd) ic.commitText("", 1);                   // drop a selection first
        ic.deleteSurroundingText(MAX_PREVIEW * 4, MAX_PREVIEW * 4);     // everything around the cursor
        ic.commitText(text, 1);
        ic.endBatchEdit();
    }

    /** Turn the plain text into the converted message and put it in the field. */
    private boolean convertNow(InputConnection ic, String plain) {
        if (plain.isEmpty() || plain.length() > MAX_PREVIEW) return false;
        if (plain.indexOf('\u2066') >= 0 || plain.indexOf('\u202e') >= 0) return false;   // already converted
        Converter.Result r = Converter.convert(plain, rloOn(), zwjOn());
        replaceAllBlind(ic, r.text);
        undoOriginal = plain;
        undoConverted = r.text;
        shadow = r.text;
        shadowKnown = true;
        selStart = selEnd = r.text.length();
        lastPreview = "";
        updateStatus();
        return true;
    }

    /** Put the plain text back in the field (before editing, or when you tap undo). */
    private void restorePlain(InputConnection ic) {
        String plain = undoOriginal;
        undoOriginal = null;
        undoConverted = null;
        lastPreview = "";
        if (plain != null) {
            replaceAllBlind(ic, plain);
            shadow = plain;
            shadowKnown = true;
            selStart = selEnd = plain.length();
        }
        updateStatus();
    }

    /** Tap the status pill: convert now, or undo. */
    private void toggleConvert() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        handler.removeCallbacks(autoConvert);
        if (undoConverted != null) {
            restorePlain(ic);
            return;
        }
        if (!shadowKnown) {
            shadow = fieldText(ic);
            shadowKnown = true;
        }
        convertNow(ic, shadow);
    }

    private void scheduleAuto() {
        handler.removeCallbacks(autoConvert);
        if (autoOn() && undoConverted == null) handler.postDelayed(autoConvert, AUTO_DELAY_MS);
    }

    /** Typing paused: convert the field by itself. */
    private void autoConvertNow() {
        if (!autoOn() || undoConverted != null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (!shadowKnown) {
            shadow = fieldText(ic);
            shadowKnown = true;
        }
        convertNow(ic, shadow);
    }

    // ------------------------------------------------------------------ live status (points + chars)

    /** Count again shortly after the text changes; the short delay also coalesces fast keystrokes. */
    private void schedulePoints() {
        handler.removeCallbacks(refreshPoints);
        handler.postDelayed(refreshPoints, 40);
    }

    private void scheduleReconcile(long delayMs) {
        handler.removeCallbacks(reconcile);
        handler.postDelayed(reconcile, delayMs);
    }

    /** Read the real text once (typing has paused) and fix the keyboard's own copy if it drifted. */
    private void reconcileNow() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        String real = fieldText(ic);
        boolean changedOutside = false;
        if (undoConverted != null) {
            if (!real.equals(undoConverted)) {      // the app changed it (sent and cleared, or edited)
                undoOriginal = null;
                undoConverted = null;
                shadow = real;
                shadowKnown = true;
                lastPreview = "";
                changedOutside = true;
            }
        } else if (!shadowKnown || !real.equals(shadow)) {
            shadow = real;
            shadowKnown = true;
            lastPreview = "";
            changedOutside = true;
        }
        updateStatus();
        if (changedOutside) scheduleAuto();         // text arrived from outside (paste, draft): convert it too
    }

    private void updatePointsNow() {
        updateStatus();
    }

    /** Points and characters, live. Uses only the keyboard's own copy of the text, never the app. */
    private void updateStatus() {
        if (statusKey == null) return;
        int budget = Converter.POINT_BUDGET;

        if (undoConverted != null && undoOriginal != null) {            // converted and ready to send
            int chars = undoOriginal.codePointCount(0, undoOriginal.length());
            int pts = undoConverted.codePointCount(0, undoConverted.length());
            showStatus(pts + "/" + budget + " pts", chars + " chars \u00B7 ready", pts, true);
            return;
        }
        if (!shadowKnown) return;
        String all = shadow;
        if (all.indexOf('\u2066') >= 0 || all.indexOf('\u202e') >= 0) {   // converted text that was already in the box
            int pts = all.codePointCount(0, all.length());
            showStatus(pts + "/" + budget + " pts", "converted", pts, true);
            return;
        }
        boolean rlo = rloOn();
        boolean zwj = zwjOn();
        String key = rlo + "|" + zwj + "|" + all;
        if (key.equals(lastPreview)) return;       // nothing changed since the last count
        lastPreview = key;

        int chars = all.codePointCount(0, all.length());
        if (all.isEmpty()) {
            showStatus("0/" + budget + " pts", "0 chars", 0, false);
        } else if (all.length() > MAX_PREVIEW) {
            showStatus("too long", chars + " chars", budget + 1, false);
        } else {
            Converter.Result r = Converter.convert(all, rlo, zwj);
            showStatus(r.points + "/" + budget + " pts", chars + " chars", r.points, false);
        }
    }

    private void showStatus(String main, String sub, int pts, boolean ready) {
        int budget = Converter.POINT_BUDGET;
        int tint = pts > budget ? RED : (pts * 100 > budget * 80 ? AMBER : MINT);
        statusKey.setLabel(main);
        statusKey.setSubLabel(sub);
        statusKey.setTextTint(pts > budget ? RED : FG);
        statusKey.setProgress(Math.min(1f, pts / (float) budget), tint);
        statusKey.setOutline(ready ? MINT : (pts > budget ? RED : 0));
    }

    // ------------------------------------------------------------------ clipboard history

    private String currentClipboardText() {
        try {
            ClipData data = clipboard.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return null;
            CharSequence text = data.getItemAt(0).coerceToText(this);
            if (text == null) return null;
            String s = text.toString();
            if (s.trim().isEmpty()) return null;
            return s.replace(SEP, " ");
        } catch (Exception e) {
            return null;     // clipboard can be unreadable at times
        }
    }

    /** fromCopy = a real copy just happened. Otherwise this is only a sync, which must not revive removed clips. */
    private void captureClipboard(boolean fromCopy) {
        String s = currentClipboardText();
        if (s == null) return;
        if (fromCopy) blockedClip = null;
        else if (s.equals(blockedClip)) return;
        addClip(s);
    }

    private void removeClip(String s) {
        clips.remove(s);
        saveClips();
        if (s.equals(currentClipboardText())) {
            blockedClip = s;
            clearSystemClipboard();
        }
        rebuildClipList();
    }

    private void clearAllClips() {
        clips.clear();
        saveClips();
        blockedClip = currentClipboardText();
        clearSystemClipboard();
        rebuildClipList();
    }

    private void clearSystemClipboard() {
        try {
            if (Build.VERSION.SDK_INT >= 28) clipboard.clearPrimaryClip();
            else clipboard.setPrimaryClip(ClipData.newPlainText("", ""));
        } catch (Exception ignored) {
            // if it cannot be cleared, blockedClip still keeps it from coming back
        }
    }

    private void addClip(String s) {
        clips.remove(s);
        clips.add(0, s);
        while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
        saveClips();
    }

    private void loadClips() {
        clips.clear();
        String raw = prefs.getString("clips", "");
        if (raw == null || raw.isEmpty()) return;
        for (String s : raw.split(SEP)) if (!s.isEmpty()) clips.add(s);
    }

    private void saveClips() {
        prefs.edit().putString("clips", TextUtils.join(SEP, clips)).apply();
    }
}
