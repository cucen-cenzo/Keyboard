package com.godfather.keyboard;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Minimal keyboard: letters, numbers, comma, period, question mark, space, delete, enter.
 * Top strip: clipboard history, RLO / ZWJ / AUTO switches and a live status pill (points + chars).
 * AUTO converts the message by itself: when typing pauses, and right before enter sends it.
 */
public class GodfatherIME extends InputMethodService {

    // ---- look: liquid frost over the Samsung key geometry (measured from a 1080 px wide screenshot) --
    // Every size is in "design px" on a 1080 px wide screen and is scaled to the real screen.
    //   keys: 88 px wide (letters), 96 px tall (numbers) / 116 px tall (letters), 17 px gap sideways,
    //   34 px gap between rows, row 3 inset by half a key, space bar centred.
    private static final int FG = 0xFFF2F2F5;
    private static final int MUTED = 0xFF9A9AA3;
    private static final int RED = 0xFFFF7B8A;
    private static final int MINT = 0xFF7CF5C8;       // healthy / switched on
    private static final int AMBER = 0xFFFFD27A;      // getting close to the limit
    private static final int DOT_OFF = 0xFF5A5A63;

    // dark theme: charcoal keys on a near-black backdrop
    private static final Skin SKIN_KEY = new Skin(0xFF2B2B2F, 0xFF222226, 0x33FFFFFF, 0xFF45454B, 0xFF3A3A40, false, false);
    private static final Skin SKIN_FUNC = new Skin(0xFF1C1C1F, 0xFF161619, 0x26FFFFFF, 0xFF3A3A40, 0xFF303036, false, false);
    private static final Skin SKIN_CHIP_OFF = new Skin(0xFF1F1F23, 0xFF18181B, 0x26FFFFFF, 0xFF3A3A40, 0xFF303036, false, false);
    private static final Skin SKIN_COUNTER = new Skin(0xFF1A1A1D, 0xFF131316, 0x26FFFFFF, 0x40FFFFFF, 0x30FFFFFF, false, false);

    private static final long AUTO_DELAY_MS = 700;    // how long typing must pause before auto-convert

    // the keyboard's own backdrop: near-black
    private static final int[] BACKDROP = {0xFF101012, 0xFF0B0B0D, 0xFF070708};

    // emoji panel tabs: recent + the Unicode groups (group numbers match assets/emoji.txt)
    private static final String[] EMOJI_TAB_ICONS = {
            "\uD83D\uDD52", "\uD83D\uDE00", "\uD83D\uDC4B", "\uD83D\uDC35", "\uD83C\uDF47",
            "\uD83C\uDF0D", "\uD83C\uDF83", "\uD83D\uDC53", "\uD83C\uDFE7", "\uD83C\uDFC1"};
    private static final String[] EMOJI_TAB_NAMES = {
            "recent", "smileys", "people", "animals", "food", "travel", "activities", "objects", "symbols", "flags"};
    private static final int[] EMOJI_TAB_GROUPS = {-1, 0, 1, 3, 4, 5, 6, 7, 8, 9};
    private static final int EMOJI_COLUMNS = 7;
    private static final int EMOJI_RECENT_MAX = 32;
    private static final String TONE_PLACEHOLDER = "\uD83C\uDFFB";   // light skin tone, stands in for any tone
    private static final String[] TONES = {
            "", "\uD83C\uDFFB", "\uD83C\uDFFC", "\uD83C\uDFFD", "\uD83C\uDFFE", "\uD83C\uDFFF"};

    /** One emoji from assets/emoji.txt. */
    private static final class EmojiEntry {
        final String plain;       // the default (yellow) form
        final String toned;       // form with the placeholder skin tone, or null if it has no skin tones
        final int group;
        final String[] words;     // lower-case name + keywords, used by the search
        String shown;             // what is displayed and typed right now (plain or with the chosen tone)

        EmojiEntry(String plain, String toned, int group, String[] words) {
            this.plain = plain;
            this.toned = toned;
            this.group = group;
            this.words = words;
            this.shown = plain;
        }
    }

    /** Accent colours the settings screen offers (switched-on chips, selected tabs, pinned clips). */
    static final int[] ACCENTS = {0xFF7CF5C8, 0xFF7CB8FF, 0xFFB794FF, 0xFFFF8FB8, 0xFFFFB86B};

    // symbol pages: same order as the letter keys (q..p, a..l, z..m)
    private static final String[][] SYMBOLS = {
            {"@", "#", "$", "%", "&", "-", "+", "(", ")", "/",
                    "*", "\"", "'", ":", ";", "!", "?", "=", "_",
                    "~", "`", "|", "^", "\\", "{", "}"},
            {"<", ">", "[", "]", "\u00AB", "\u00BB", "\u20AC", "\u00A3", "\u00A5", "\u00A2",
                    "\u00B0", "\u00A9", "\u00AE", "\u2122", "\u00A7", "\u00B6", "\u00BF", "\u00A1", "\u2022",
                    "\u201C", "\u201D", "\u2018", "\u2019", "\u2026", "\u00B1", "\u00F7"}};

    private static final String PREFS = "godfather";
    private static final String SEP = "\u0001";
    private static final int MAX_CLIPS = 25;
    private static final int MAX_PREVIEW = 600;       // longer text is not converted or previewed

    private SharedPreferences prefs;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> clips = new ArrayList<>();
    private String blockedClip;                       // a clip the user removed; do not re-add it on sync

    private LinearLayout keyboardPane;
    private LinearLayout clipPane;
    private LinearLayout emojiPane;
    private LinearLayout emojiBrowse;
    private LinearLayout emojiSearch;
    private GridView emojiBrowseGrid;
    private GridView emojiSearchGrid;
    private EmojiAdapter browseAdapter;
    private EmojiAdapter searchAdapter;
    private KeyView[] emojiTabs;
    private KeyView toneKey;
    private TextView searchQueryView;
    private final ArrayList<EmojiEntry> emojiEntries = new ArrayList<>();
    private final ArrayList<String> emojiRecent = new ArrayList<>();
    private final Paint glyphPaint = new Paint();
    private boolean emojiLoaded;
    private int emojiTab = -1;
    private int emojiTone;
    private String searchQuery = "";
    private LinearLayout clipList;
    private float scale = 1f;

    // settings (changed on the setup screen)
    private float heightFactor = 1f;
    private int accent = ACCENTS[0];
    private Skin skinChipOn = skinFor(ACCENTS[0]);
    private boolean swipeOn = true;
    private long appliedRev;

    // symbols: 0 = letters, 1 = first symbol page, 2 = second symbol page
    private int symbolMode = 0;
    private KeyView symbolKey;

    // pinned clips stay on top and survive "clear"
    private final List<String> pins = new ArrayList<>();
    private KeyboardLayout keyboardRoot;
    private KeyView rloKey;
    private KeyView zwjKey;
    private KeyView statusKey;
    private KeyView autoKey;

    // shift: 0 = off, 1 = next letter only, 2 = caps lock
    private int shiftState = 0;
    private long lastShiftTap = 0;
    private KeyView shiftKey;
    private final List<KeyView> letterViews = new ArrayList<>();
    private final List<String> letterBase = new ArrayList<>();

    // what the field held before the last convert, so convert can be undone
    private String undoOriginal;
    private String undoConverted;
    private String lastPreview = "";

    // The keyboard keeps its own copy of what it typed, so counting points never waits on the app.
    // The real text is only read once, after you pause typing.
    private String shadow = "";
    private boolean shadowKnown = false;
    private int selStart = 0;
    private int selEnd = 0;

    private final Runnable refreshPoints = new Runnable() {
        @Override
        public void run() {
            updatePointsNow();
        }
    };

    private final Runnable autoConvert = new Runnable() {
        @Override
        public void run() {
            autoConvertNow();
        }
    };

    private final Runnable reconcile = new Runnable() {
        @Override
        public void run() {
            reconcileNow();
        }
    };

    private final Runnable repeatDelete = new Runnable() {
        @Override
        public void run() {
            deleteOne();
            handler.postDelayed(this, 40);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadClips();
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {
                captureClipboard(true);
            }
        };
        clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (clipboard != null && clipListener != null) {
            clipboard.removePrimaryClipChangedListener(clipListener);
        }
        handler.removeCallbacks(repeatDelete);
        handler.removeCallbacks(refreshPoints);
        handler.removeCallbacks(reconcile);
        handler.removeCallbacks(autoConvert);
        super.onDestroy();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        // the setup screen changed a setting (key height, accent, swipe): build the keyboard again
        if (prefs.getLong("settingsRev", 0) != appliedRev) setInputView(onCreateInputView());
        symbolMode = 0;
        askForHighRefreshRate();
        captureClipboard(false);
        handler.removeCallbacks(autoConvert);
        undoOriginal = null;
        undoConverted = null;
        lastPreview = "";
        shiftState = 0;
        refreshShift();
        shadow = "";
        shadowKnown = false;
        showKeyboard();
        scheduleReconcile(150);
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        selStart = newSelStart;
        selEnd = newSelEnd;
        scheduleReconcile(450);   // text may have changed from outside (paste, sent message)
    }

    /** Ask the display for its top refresh rate while the keyboard is up (smoother key feedback). */
    private void askForHighRefreshRate() {
        try {
            Dialog dialog = getWindow();
            if (dialog == null) return;
            Window w = dialog.getWindow();
            if (w == null) return;
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.preferredRefreshRate = 120f;
            w.setAttributes(lp);
        } catch (Exception ignored) {
            // not supported on this device; the keyboard still works
        }
    }

    // ------------------------------------------------------------------ views

    @Override
    public View onCreateInputView() {
        loadSettings();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        scale = Math.min(dm.widthPixels, dm.heightPixels) / 1080f;   // same key size in landscape

        KeyboardLayout root = new KeyboardLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, BACKDROP));
        root.setPadding(u(14.5f), 0, u(14.5f), u(24));

        letterViews.clear();
        letterBase.clear();

        keyboardPane = new LinearLayout(this);
        keyboardPane.setOrientation(LinearLayout.VERTICAL);
        buildKeyboard(keyboardPane);

        clipPane = new LinearLayout(this);
        clipPane.setOrientation(LinearLayout.VERTICAL);
        buildClipPane(clipPane);

        emojiPane = new LinearLayout(this);
        emojiPane.setOrientation(LinearLayout.VERTICAL);
        buildEmojiPane(emojiPane);

        root.addView(keyboardPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(clipPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(emojiPane, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setKeyPane(keyboardPane);
        root.setMaxReach(u(220));                    // a touch this far from every key is ignored
        root.setBubbleSizes(u(24), u(24), u(8));     // popup bubble above the pressed key
        root.setDriftPx(u(22));                      // a small slip past a key's edge keeps the first key
        root.setSwipe(swipeOn, u(36), u(26), u(70), (mode, direction) -> onSwipe(mode, direction));
        keyboardRoot = root;
        showKeyboard();
        return root;
    }

    private void buildKeyboard(LinearLayout pane) {
        // tools row (small): clipboard, the switches, and the live counter
        LinearLayout tools = row(92);
        KeyView clipKey = pill("", 0.8f, 36);
        clipKey.setIcon(KeyView.Icon.CLIP);
        clipKey.setContentDescription("clipboard");
        clipKey.setAction(this::showClips);
        rloKey = pill("RLO", 1.0f, 28);
        rloKey.setAction(() -> flip("rlo"));
        zwjKey = pill("ZWJ", 1.0f, 28);
        zwjKey.setAction(() -> flip("zwj"));
        autoKey = pill("AUTO", 1.1f, 28);
        autoKey.setAction(() -> flip("auto"));
        statusKey = pill("0/" + Converter.POINT_BUDGET + " pts", 2.3f, 28);
        statusKey.setSkin(SKIN_COUNTER);
        statusKey.setSubLabel("0 chars");
        statusKey.setProgress(0f, MINT);
        statusKey.setAction(this::toggleConvert);
        tools.addView(clipKey);
        tools.addView(rloKey);
        tools.addView(zwjKey);
        tools.addView(autoKey);
        tools.addView(statusKey);
        pane.addView(tools);
        refreshSwitches();

        // numbers: shorter keys (96 px) like Samsung
        LinearLayout nums = row(130);
        for (char c : "1234567890".toCharArray()) nums.addView(typingKey(String.valueOf(c), 56, SKIN_KEY));
        pane.addView(nums);

        // q w e r t y u i o p
        LinearLayout r1 = row(150);
        for (char c : "qwertyuiop".toCharArray()) r1.addView(letterKey(String.valueOf(c)));
        pane.addView(r1);

        // a s d f g h j k l  (inset by half a key each side)
        LinearLayout r2 = row(150);
        r2.addView(spacer(0.5f));
        for (char c : "asdfghjkl".toCharArray()) r2.addView(letterKey(String.valueOf(c)));
        r2.addView(spacer(0.5f));
        pane.addView(r2);

        // shift  z x c v b n m  delete
        LinearLayout r3 = row(150);
        shiftKey = key("", 1.352f, 40, SKIN_FUNC, false);
        shiftKey.setIcon(KeyView.Icon.SHIFT);
        shiftKey.setContentDescription("shift");
        shiftKey.setAction(this::onShiftTap);
        r3.addView(shiftKey);
        r3.addView(spacer(0.143f));
        for (char c : "zxcvbnm".toCharArray()) r3.addView(letterKey(String.valueOf(c)));
        r3.addView(spacer(0.15f));
        KeyView del = key("", 1.352f, 40, SKIN_FUNC, true);
        del.setIcon(KeyView.Icon.BACKSPACE);
        del.setContentDescription("delete");
        del.setAction(() -> {
            deleteOne();
            handler.postDelayed(repeatDelete, 380);
        });
        del.setOnRelease(() -> handler.removeCallbacks(repeatDelete));
        del.setSwipeMode(2);                      // swipe left: delete words
        r3.addView(del);
        pane.addView(r3);

        // ?123  ?  ,  emoji  [ space ]  .  enter
        LinearLayout bottom = row(150);
        symbolKey = key("?123", 1.3f, 36, SKIN_FUNC, false);
        symbolKey.setContentDescription("symbols");
        symbolKey.setAction(this::toggleSymbols);
        bottom.addView(symbolKey);
        bottom.addView(typingKey("?", 56, SKIN_FUNC, 1f));
        bottom.addView(typingKey(",", 66, SKIN_KEY));
        KeyView emojiKey = key("\uD83D\uDE00", 1f, 48, SKIN_FUNC, false);
        emojiKey.setContentDescription("emoji");
        emojiKey.setAction(this::showEmoji);
        bottom.addView(emojiKey);
        KeyView space = key("godfather", 3.2f, 34, SKIN_KEY, false);
        space.setTextTint(MUTED);
        space.setAction(() -> typed(" "));
        space.setSwipeMode(1);                    // swipe sideways: move the cursor
        bottom.addView(space);
        bottom.addView(typingKey(".", 66, SKIN_KEY));
        KeyView enter = key("", 1.5f, 40, SKIN_FUNC, false);
        enter.setIcon(KeyView.Icon.ENTER);
        enter.setContentDescription("enter");
        enter.setAction(this::enterPressed);
        bottom.addView(enter);
        pane.addView(bottom);
    }

    private KeyView typingKey(final String label, float textPx, Skin skin) {
        return typingKey(label, textPx, skin, 1f);
    }

    private KeyView typingKey(final String label, float textPx, Skin skin, float weight) {
        KeyView k = key(label, weight, textPx, skin, false);
        k.setPreview(true);
        k.setAction(() -> typed(label));
        return k;
    }

    /** A letter key: shows a capital when shift is on, and types it. */
    private KeyView letterKey(final String base) {
        KeyView k = key(base, 1f, 66, SKIN_KEY, false);
        k.setPreview(true);
        k.setAction(() -> typedLetter(base));
        letterViews.add(k);
        letterBase.add(base);
        return k;
    }

    private void buildClipPane(LinearLayout pane) {
        LinearLayout head = row(110);
        KeyView back = key("\u2190 back", 1f, 40, SKIN_FUNC, false);
        back.setAction(this::showKeyboard);
        KeyView clear = key("clear unpinned", 1.4f, 36, SKIN_FUNC, false);
        clear.setAction(this::clearAllClips);
        head.addView(back);
        head.addView(clear);
        pane.addView(head);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(clipList, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // 110 + 712 = 822: exactly the height of the letter keyboard, so nothing jumps when this opens
        pane.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, uh(712)));
    }

    private void buildEmojiPane(LinearLayout pane) {
        // ---- browse view: header, category tabs, big scrolling grid (822 design px in total, like the keyboard)
        emojiBrowse = new LinearLayout(this);
        emojiBrowse.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = row(130);
        KeyView back = key("\u2190 back", 1.3f, 40, SKIN_FUNC, false);
        back.setAction(this::showKeyboard);
        KeyView find = key("\uD83D\uDD0D", 1f, 52, SKIN_FUNC, false);
        find.setContentDescription("search emoji");
        find.setAction(this::enterEmojiSearch);
        toneKey = key("\uD83D\uDC4B", 1f, 52, SKIN_FUNC, false);
        toneKey.setContentDescription("skin tone");
        toneKey.setAction(this::cycleTone);
        if (emojiLoaded) toneKey.setLabel(toneLabel());
        KeyView del = key("", 1.3f, 40, SKIN_FUNC, true);
        del.setIcon(KeyView.Icon.BACKSPACE);
        del.setContentDescription("delete");
        del.setAction(() -> {
            deleteOne();
            handler.postDelayed(repeatDelete, 380);
        });
        del.setOnRelease(() -> handler.removeCallbacks(repeatDelete));
        head.addView(back);
        head.addView(find);
        head.addView(toneKey);
        head.addView(del);
        emojiBrowse.addView(head);

        LinearLayout tabs = row(110);
        emojiTabs = new KeyView[EMOJI_TAB_ICONS.length];
        for (int i = 0; i < EMOJI_TAB_ICONS.length; i++) {
            final int index = i;
            KeyView tab = key(EMOJI_TAB_ICONS[i], 1f, 46, SKIN_CHIP_OFF, false);
            tab.setContentDescription(EMOJI_TAB_NAMES[i]);
            tab.setAction(() -> selectEmojiTab(index));
            emojiTabs[i] = tab;
            tabs.addView(tab);
        }
        emojiBrowse.addView(tabs);

        browseAdapter = new EmojiAdapter();
        emojiBrowseGrid = makeEmojiGrid(browseAdapter);
        emojiBrowse.addView(emojiBrowseGrid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, uh(582)));
        pane.addView(emojiBrowse, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- search view: query line, a short results grid, and a small letter keyboard (also 822 design px)
        emojiSearch = new LinearLayout(this);
        emojiSearch.setOrientation(LinearLayout.VERTICAL);

        LinearLayout qrow = row(110);
        KeyView exit = key("\u2190", 1f, 48, SKIN_FUNC, false);
        exit.setContentDescription("back to emoji");
        exit.setAction(this::exitEmojiSearch);
        qrow.addView(exit);
        searchQueryView = new TextView(this);
        searchQueryView.setSingleLine(true);
        searchQueryView.setEllipsize(TextUtils.TruncateAt.START);
        searchQueryView.setGravity(Gravity.CENTER_VERTICAL);
        searchQueryView.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(46));
        searchQueryView.setPadding(u(28), 0, u(28), 0);
        searchQueryView.setBackground(listBackground(0xFF26262A, 0x33FFFFFF));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 4f);
        qlp.setMargins(sideLeft(), u(6), sideRight(), u(6));
        qrow.addView(searchQueryView, qlp);
        emojiSearch.addView(qrow);

        searchAdapter = new EmojiAdapter();
        emojiSearchGrid = makeEmojiGrid(searchAdapter);
        emojiSearch.addView(emojiSearchGrid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, uh(232)));

        LinearLayout k1 = row(120);
        for (char c : "qwertyuiop".toCharArray()) k1.addView(searchLetter(c));
        emojiSearch.addView(k1);
        LinearLayout k2 = row(120);
        k2.addView(spacer(0.5f));
        for (char c : "asdfghjkl".toCharArray()) k2.addView(searchLetter(c));
        k2.addView(spacer(0.5f));
        emojiSearch.addView(k2);
        LinearLayout k3 = row(120);
        k3.addView(spacer(0.5f));
        for (char c : "zxcvbnm".toCharArray()) k3.addView(searchLetter(c));
        k3.addView(spacer(0.5f));
        KeyView sdel = key("", 2f, 40, SKIN_FUNC, true);
        sdel.setIcon(KeyView.Icon.BACKSPACE);
        sdel.setContentDescription("delete");
        sdel.setAction(() -> {
            searchBackspace();
            handler.postDelayed(repeatSearchDelete, 380);
        });
        sdel.setOnRelease(() -> handler.removeCallbacks(repeatSearchDelete));
        k3.addView(sdel);
        emojiSearch.addView(k3);
        LinearLayout k4 = row(120);
        KeyView clear = key("clear", 3f, 40, SKIN_FUNC, false);
        clear.setAction(() -> {
            searchQuery = "";
            refreshEmojiSearch();
        });
        KeyView space = key("space", 7f, 40, SKIN_KEY, false);
        space.setTextTint(MUTED);
        space.setAction(() -> searchAppend(" "));
        k4.addView(clear);
        k4.addView(space);
        emojiSearch.addView(k4);
        emojiSearch.setVisibility(View.GONE);
        pane.addView(emojiSearch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private KeyView searchLetter(final char c) {
        KeyView k = key(String.valueOf(c), 1f, 52, SKIN_KEY, false);
        k.setAction(() -> searchAppend(String.valueOf(c)));
        return k;
    }

    private GridView makeEmojiGrid(final EmojiAdapter adapter) {
        GridView grid = new GridView(this);
        grid.setNumColumns(EMOJI_COLUMNS);
        grid.setHorizontalSpacing(0);
        grid.setVerticalSpacing(0);
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setSelector(new ColorDrawable(0x33FFFFFF));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < adapter.items.size()) onEmojiChosen(adapter.items.get(position));
        });
        return grid;
    }

    /** The grid shows plain strings; each one is already the final emoji (tone applied). */
    private final class EmojiAdapter extends BaseAdapter {
        private List<String> items = new ArrayList<>();

        void setItems(List<String> list) {
            items = list;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView cell;
            if (convertView instanceof TextView) {
                cell = (TextView) convertView;
            } else {
                cell = new TextView(GodfatherIME.this);
                cell.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, uh(128)));
                cell.setGravity(Gravity.CENTER);
                cell.setIncludeFontPadding(false);
                cell.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(66));
            }
            cell.setText(items.get(position));
            return cell;
        }
    }

    private final Runnable repeatSearchDelete = new Runnable() {
        @Override
        public void run() {
            searchBackspace();
            handler.postDelayed(this, 55);
        }
    };

    // ------------------------------------------------------------------ emoji data, tabs, search

    /** Reads assets/emoji.txt once, keeping only the emoji this phone can actually draw. */
    private void ensureEmojiLoaded() {
        if (emojiLoaded) return;
        emojiLoaded = true;
        emojiTone = Math.max(0, Math.min(TONES.length - 1, prefs.getInt("emojiTone", 0)));
        String saved = prefs.getString("emojiRecent", "");
        for (String piece : saved.split("\n")) {
            if (!piece.isEmpty() && emojiRecent.size() < EMOJI_RECENT_MAX) emojiRecent.add(piece);
        }
        ArrayList<EmojiEntry> all = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open("emoji.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\t", 4);
                if (p.length < 4 || p[0].isEmpty()) continue;
                int group;
                try {
                    group = Integer.parseInt(p[2]);
                } catch (NumberFormatException e) {
                    continue;
                }
                all.add(new EmojiEntry(p[0], p[1].equals("-") ? null : p[1], group, p[3].split(" ")));
            }
        } catch (IOException e) {
            // no emoji list: the panel just stays empty
        }
        for (EmojiEntry e : all) {
            if (glyphPaint.hasGlyph(e.plain)) emojiEntries.add(e);
        }
        if (emojiEntries.size() < all.size() / 4) {   // the glyph test looks unreliable here: show everything
            emojiEntries.clear();
            emojiEntries.addAll(all);
        }
        applyTone();
        toneKey.setLabel(toneLabel());
    }

    /** Sets EmojiEntry.shown for the chosen skin tone (falls back to the plain form if the phone lacks the glyph). */
    private void applyTone() {
        for (EmojiEntry e : emojiEntries) {
            e.shown = e.plain;
            if (emojiTone > 0 && e.toned != null) {
                String t = e.toned.replace(TONE_PLACEHOLDER, TONES[emojiTone]);
                if (glyphPaint.hasGlyph(t)) e.shown = t;
            }
        }
    }

    private String toneLabel() {
        String hand = "\uD83D\uDC4B" + TONES[emojiTone];
        return glyphPaint.hasGlyph(hand) ? hand : "\uD83D\uDC4B";
    }

    private void cycleTone() {
        emojiTone = (emojiTone + 1) % TONES.length;
        prefs.edit().putInt("emojiTone", emojiTone).apply();
        applyTone();
        toneKey.setLabel(toneLabel());
        selectEmojiTab(emojiTab < 0 ? 1 : emojiTab);
    }

    private void selectEmojiTab(int index) {
        if (index < 0 || index >= EMOJI_TAB_GROUPS.length) index = 1;
        emojiTab = index;
        for (int i = 0; i < emojiTabs.length; i++) {
            emojiTabs[i].setSkin(i == index ? skinChipOn : SKIN_CHIP_OFF);
        }
        ArrayList<String> list = new ArrayList<>();
        if (index == 0) {
            list.addAll(emojiRecent);
        } else {
            int group = EMOJI_TAB_GROUPS[index];
            for (EmojiEntry e : emojiEntries) {
                if (e.group == group) list.add(e.shown);
            }
        }
        browseAdapter.setItems(list);
        emojiBrowseGrid.setSelection(0);
    }

    private void onEmojiChosen(String emoji) {
        typed(emoji);
        emojiRecent.remove(emoji);
        emojiRecent.add(0, emoji);
        while (emojiRecent.size() > EMOJI_RECENT_MAX) emojiRecent.remove(emojiRecent.size() - 1);
        prefs.edit().putString("emojiRecent", TextUtils.join("\n", emojiRecent)).apply();
    }

    private void enterEmojiSearch() {
        searchQuery = "";
        emojiBrowse.setVisibility(View.GONE);
        emojiSearch.setVisibility(View.VISIBLE);
        refreshEmojiSearch();
    }

    private void exitEmojiSearch() {
        handler.removeCallbacks(repeatSearchDelete);
        emojiSearch.setVisibility(View.GONE);
        emojiBrowse.setVisibility(View.VISIBLE);
        selectEmojiTab(emojiTab < 0 ? 1 : emojiTab);
    }

    private void searchAppend(String text) {
        if (searchQuery.length() >= 32) return;
        searchQuery += text;
        refreshEmojiSearch();
    }

    private void searchBackspace() {
        if (searchQuery.isEmpty()) {
            handler.removeCallbacks(repeatSearchDelete);
            return;
        }
        searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
        refreshEmojiSearch();
    }

    private void refreshEmojiSearch() {
        if (searchQuery.isEmpty()) {
            searchQueryView.setText("Search emoji");
            searchQueryView.setTextColor(MUTED);
        } else {
            searchQueryView.setText(searchQuery + "|");
            searchQueryView.setTextColor(FG);
        }
        searchAdapter.setItems(searchQuery.trim().isEmpty()
                ? new ArrayList<>(emojiRecent) : searchEmoji(searchQuery));
        emojiSearchGrid.setSelection(0);
    }

    /** Every typed word must start a word of the emoji's name or keywords; whole-word matches come first. */
    private ArrayList<String> searchEmoji(String query) {
        String[] tokens = query.trim().toLowerCase(Locale.ROOT).split("\\s+");
        ArrayList<String> exact = new ArrayList<>();
        ArrayList<String> partial = new ArrayList<>();
        for (EmojiEntry e : emojiEntries) {
            boolean allExact = true;
            boolean matches = true;
            for (String token : tokens) {
                int best = -1;                         // 0 = whole word, 1 = start of a word
                for (String word : e.words) {
                    if (word.equals(token)) {
                        best = 0;
                        break;
                    }
                    if (best < 0 && word.startsWith(token)) best = 1;
                }
                if (best < 0) {
                    matches = false;
                    break;
                }
                if (best == 1) allExact = false;
            }
            if (!matches) continue;
            if (allExact) exact.add(e.shown);
            else partial.add(e.shown);
        }
        exact.addAll(partial);
        return exact;
    }

    private void rebuildClipList() {
        clipList.removeAllViews();
        if (pins.isEmpty() && clips.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Nothing copied yet\nCopy some text and it shows up here.");
            empty.setTextColor(MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(40));
            empty.setPadding(u(40), uh(220), u(40), uh(40));
            clipList.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return;
        }
        if (!pins.isEmpty()) {
            addClipLabel("PINNED");
            for (String clip : new ArrayList<>(pins)) addClipCard(clip, true);
        }
        if (!clips.isEmpty()) {
            if (!pins.isEmpty()) addClipLabel("RECENT");
            for (String clip : new ArrayList<>(clips)) addClipCard(clip, false);
        }
    }

    private void addClipLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(MUTED);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(28));
        label.setLetterSpacing(0.12f);
        label.setPadding(u(16), u(14), u(16), u(4));
        clipList.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** One clip: tap the text to paste it, the pin keeps it on top, the cross deletes it. */
    private void addClipCard(final String clip, final boolean pinned) {
        int cardFill = 0xFF26262A;
        int cardPressed = 0xFF34343A;
        int cardEdge = 0x33FFFFFF;
        int pinFill = mix(accent, 0xFF18181B, 0.16f);
        int pinPressed = mix(accent, 0xFF18181B, 0.30f);

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, uh(140));
        lineLp.setMargins(sideLeft(), u(7), sideRight(), u(7));
        line.setLayoutParams(lineLp);

        TextView text = new TextView(this);
        text.setText(clip);
        text.setMaxLines(3);
        text.setEllipsize(TextUtils.TruncateAt.END);
        text.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        text.setTextColor(FG);
        text.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(38));
        text.setPadding(u(28), u(8), u(28), u(8));
        text.setBackground(pinned ? listBackground(pinFill, pinPressed, accent)
                : listBackground(cardFill, cardPressed, cardEdge));
        text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        text.setOnClickListener(v -> {
            typed(clip);
            showKeyboard();
        });

        TextView pin = new TextView(this);
        pin.setText("\uD83D\uDCCC");
        pin.setGravity(Gravity.CENTER);
        pin.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(46));
        pin.setAlpha(pinned ? 1f : 0.5f);
        pin.setContentDescription(pinned ? "unpin" : "pin");
        pin.setBackground(pinned ? listBackground(pinPressed, mix(accent, 0xFF18181B, 0.45f), accent)
                : listBackground(cardFill, cardPressed, cardEdge));
        LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(u(118), ViewGroup.LayoutParams.MATCH_PARENT);
        pinLp.setMargins(u(10), 0, 0, 0);
        pin.setLayoutParams(pinLp);
        pin.setOnClickListener(v -> togglePin(clip));

        TextView remove = new TextView(this);
        remove.setText("\u2715");
        remove.setGravity(Gravity.CENTER);
        remove.setTextColor(RED);
        remove.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(44));
        remove.setContentDescription("delete");
        remove.setBackground(listBackground(0xFF2E2022, 0xFF4A2A2E, 0x66FF7B8A));
        LinearLayout.LayoutParams rmLp = new LinearLayout.LayoutParams(u(118), ViewGroup.LayoutParams.MATCH_PARENT);
        rmLp.setMargins(u(10), 0, 0, 0);
        remove.setLayoutParams(rmLp);
        remove.setOnClickListener(v -> removeClip(clip));

        line.addView(text);
        line.addView(pin);
        line.addView(remove);
        clipList.addView(line);
    }

    private void togglePin(String s) {
        if (pins.contains(s)) {            // unpin: back to the recent list, at the top
            pins.remove(s);
            clips.remove(s);
            clips.add(0, s);
            while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
        } else {                           // pin: move it out of the recent list
            clips.remove(s);
            pins.add(0, s);
        }
        saveClips();
        savePins();
        rebuildClipList();
    }

    // ------------------------------------------------------------------ settings + colour helpers

    /** Blends two colours: t = 1 gives a, t = 0 gives b. */
    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 0xFF) * t + ((b >> 16) & 0xFF) * (1f - t));
        int g = Math.round(((a >> 8) & 0xFF) * t + ((b >> 8) & 0xFF) * (1f - t));
        int bl = Math.round((a & 0xFF) * t + (b & 0xFF) * (1f - t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** The "switched on" key look for an accent colour. */
    private static Skin skinFor(int accentColor) {
        int dark = 0xFF1A1A1D;
        return new Skin(mix(accentColor, dark, 0.35f), mix(accentColor, dark, 0.27f), accentColor,
                mix(accentColor, dark, 0.45f), mix(accentColor, dark, 0.35f), false, false);
    }

    private void loadSettings() {
        heightFactor = Math.max(80, Math.min(130, prefs.getInt("keyHeight", 100))) / 100f;
        int index = Math.max(0, Math.min(ACCENTS.length - 1, prefs.getInt("accent", 0)));
        accent = ACCENTS[index];
        skinChipOn = skinFor(accent);
        swipeOn = prefs.getBoolean("swipe", true);
        appliedRev = prefs.getLong("settingsRev", 0);
    }

    // ------------------------------------------------------------------ view helpers

    /** Like u(), but also follows the key-height setting. Used for every row height so all panes stay equal. */
    private int uh(float designPx) {
        return Math.round(designPx * scale * heightFactor);
    }

    /** Design px (on a 1080 px wide screen) to real pixels. */
    private int u(float designPx) {
        return Math.round(designPx * scale);
    }

    // half of the 6 px side gap on each side of a key (3 + 3, so neighbours are 6 apart)
    private int sideLeft() {
        return (int) Math.floor(3f * scale);
    }

    private int sideRight() {
        return (int) Math.ceil(3f * scale);
    }

    private LinearLayout row(int designHeight) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, uh(designHeight)));
        return r;
    }

    private View spacer(float weight) {
        View s = new View(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
        return s;
    }

    private KeyView key(String label, float weight, float textPx, Skin skin, boolean fireOnDown) {
        KeyView k = new KeyView(this, label, u(textPx), skin, FG, u(16), fireOnDown);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(sideLeft(), u(6), sideRight(), u(6));   // 6 px sideways, 12 px between rows
        k.setLayoutParams(lp);
        return k;
    }

    /** A small rounded pill for the tools row (full-height corners, bold text). */
    private KeyView pill(String label, float weight, float textPx) {
        KeyView k = new KeyView(this, label, u(textPx), SKIN_CHIP_OFF, FG, u(36), false);
        k.setBold(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(sideLeft(), u(10), sideRight(), u(10));
        k.setLayoutParams(lp);
        return k;
    }

    private StateListDrawable listBackground(int color, int pressed) {
        return listBackground(color, pressed, 0x33FFFFFF);
    }

    private StateListDrawable listBackground(int color, int pressed, int edge) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, shape(pressed, edge));
        states.addState(new int[]{}, shape(color, edge));
        return states;
    }

    private GradientDrawable shape(int color, int edge) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setStroke(Math.max(1, u(2)), edge);
        g.setCornerRadius(u(16));
        return g;
    }

    private void showKeyboard() {
        if (keyboardPane == null || clipPane == null || emojiPane == null) return;
        if (keyboardRoot != null) keyboardRoot.cancelAll();
        keyboardPane.setVisibility(View.VISIBLE);
        clipPane.setVisibility(View.GONE);
        emojiPane.setVisibility(View.GONE);
    }

    private void showEmoji() {
        if (keyboardPane == null || clipPane == null || emojiPane == null) return;
        ensureEmojiLoaded();
        if (keyboardRoot != null) keyboardRoot.cancelAll();
        keyboardPane.setVisibility(View.GONE);
        clipPane.setVisibility(View.GONE);
        emojiSearch.setVisibility(View.GONE);
        emojiBrowse.setVisibility(View.VISIBLE);
        emojiPane.setVisibility(View.VISIBLE);
        selectEmojiTab(emojiTab >= 0 ? emojiTab : (emojiRecent.isEmpty() ? 1 : 0));
    }

    private void showClips() {
        captureClipboard(false);
        rebuildClipList();
        if (keyboardRoot != null) keyboardRoot.cancelAll();
        keyboardPane.setVisibility(View.GONE);
        emojiPane.setVisibility(View.GONE);
        clipPane.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ switches

    private boolean rloOn() {
        return prefs.getBoolean("rlo", true);
    }

    private boolean zwjOn() {
        return prefs.getBoolean("zwj", true);
    }

    private boolean autoOn() {
        return prefs.getBoolean("auto", true);
    }

    private void flip(String name) {
        prefs.edit().putBoolean(name, !prefs.getBoolean(name, true)).apply();
        refreshSwitches();
        handler.removeCallbacks(autoConvert);
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && undoConverted != null) restorePlain(ic);   // output depends on the switches: start again from plain text
        lastPreview = "";
        schedulePoints();
        scheduleAuto();
    }

    private void refreshSwitches() {
        styleChip(rloKey, rloOn());
        styleChip(zwjKey, zwjOn());
        styleChip(autoKey, autoOn());
    }

    private void styleChip(KeyView k, boolean on) {
        if (k == null) return;
        k.setSkin(on ? skinChipOn : SKIN_CHIP_OFF);
        k.setTextTint(on ? FG : MUTED);
        k.setDot(on ? MINT : DOT_OFF);
    }

    // ------------------------------------------------------------------ shift

    private void onShiftTap() {
        if (symbolMode != 0) {                  // in symbol mode this key flips between the two pages
            symbolMode = symbolMode == 1 ? 2 : 1;
            refreshShift();
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (shiftState == 0) shiftState = 1;
        else if (shiftState == 1 && now - lastShiftTap < 450) shiftState = 2;   // double tap = caps lock
        else shiftState = 0;
        lastShiftTap = now;
        refreshShift();
    }

    private void toggleSymbols() {
        symbolMode = symbolMode == 0 ? 1 : 0;
        refreshShift();
    }

    private void refreshShift() {
        boolean up = shiftState != 0;
        for (int i = 0; i < letterViews.size(); i++) {
            String base = letterBase.get(i);
            String label;
            if (symbolMode != 0 && i < SYMBOLS[symbolMode - 1].length) label = SYMBOLS[symbolMode - 1][i];
            else label = up ? base.toUpperCase(Locale.ROOT) : base;
            letterViews.get(i).setLabel(label);
        }
        if (shiftKey != null) {
            if (symbolMode != 0) {
                shiftKey.setIcon(KeyView.Icon.NONE);
                shiftKey.setLabel(symbolMode == 1 ? "1/2" : "2/2");
            } else {
                shiftKey.setLabel("");
                shiftKey.setIcon(shiftState == 0 ? KeyView.Icon.SHIFT
                        : shiftState == 1 ? KeyView.Icon.SHIFT_ON : KeyView.Icon.SHIFT_LOCK);
            }
        }
        if (symbolKey != null) symbolKey.setLabel(symbolMode == 0 ? "?123" : "ABC");
    }

    private void typedLetter(String base) {
        if (symbolMode != 0) {
            int index = letterBase.indexOf(base);
            if (index >= 0 && index < SYMBOLS[symbolMode - 1].length) typed(SYMBOLS[symbolMode - 1][index]);
            return;
        }
        typed(shiftState != 0 ? base.toUpperCase(Locale.ROOT) : base);
        if (shiftState == 1) {          // one-shot shift ends after a letter
            shiftState = 0;
            refreshShift();
        }
    }

    // ------------------------------------------------------------------ typing

    private void typed(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (undoConverted != null) restorePlain(ic);   // the field holds the converted copy: go back to plain text first
        ic.commitText(s, 1);
        if (selStart != selEnd) shadowKnown = false;     // typed over a selection: real text unknown
        else if (shadowKnown) shadow = shadow + s;
        selStart = selEnd = selStart + s.length();
        schedulePoints();
        scheduleReconcile(450);
        scheduleAuto();
    }

    private void deleteOne() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (undoConverted != null) restorePlain(ic);
        if (selStart != selEnd) {            // a selection exists: delete it
            ic.commitText("", 1);
            shadowKnown = false;
            selEnd = selStart;
        } else {
            int removed = 1;
            if (shadowKnown && !shadow.isEmpty()) {
                int cut = shadow.offsetByCodePoints(shadow.length(), -1);
                removed = shadow.length() - cut;
                shadow = shadow.substring(0, cut);
            }
            ic.deleteSurroundingTextInCodePoints(1, 0);
            if (selStart > 0) selStart = selEnd = Math.max(0, selStart - removed);
        }
        schedulePoints();
        scheduleReconcile(450);
        scheduleAuto();
    }

    /** Swipe on the space bar (mode 1) moves the cursor; swipe left on backspace (mode 2) deletes words. */
    private void onSwipe(int mode, int direction) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (mode == 1) {
            int code = direction > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT;
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
            shadowKnown = false;                 // the cursor moved: re-read the field after a pause
            scheduleReconcile(450);
        } else if (mode == 2 && direction < 0) {
            deleteWordBack(ic);
        }
    }

    private void deleteWordBack(InputConnection ic) {
        if (undoConverted != null) restorePlain(ic);
        if (selStart != selEnd) {                // a selection exists: delete it
            ic.commitText("", 1);
            shadowKnown = false;
            selEnd = selStart;
        } else {
            CharSequence before = ic.getTextBeforeCursor(80, 0);
            if (before == null || before.length() == 0) return;
            int end = before.length();
            int i = end;
            while (i > 0 && Character.isWhitespace(before.charAt(i - 1))) i--;      // spaces right before the cursor
            while (i > 0 && !Character.isWhitespace(before.charAt(i - 1))) i--;     // then the word itself
            int count = end - i;
            if (count <= 0) return;
            ic.deleteSurroundingText(count, 0);
            shadowKnown = false;
            selStart = selEnd = Math.max(0, selStart - count);
        }
        schedulePoints();
        scheduleReconcile(450);
        scheduleAuto();
    }

    private void enterPressed() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;

        int action = -1;
        if (info != null && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int a = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) action = a;
        }
        if (action < 0) {                    // plain new line (multi-line box)
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
            return;
        }

        boolean sends = action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_GO
                || action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_DONE;
        handler.removeCallbacks(autoConvert);
        boolean converted = false;
        if (sends && autoOn() && undoConverted == null) {
            if (!shadowKnown) {
                shadow = fieldText(ic);
                shadowKnown = true;
            }
            converted = convertNow(ic, shadow);      // convert right before sending
        }
        final int act = action;
        if (converted) {
            // let the app apply the converted text first, then send
            handler.postDelayed(() -> {
                InputConnection again = getCurrentInputConnection();
                if (again != null) again.performEditorAction(act);
            }, 60);
        } else {
            ic.performEditorAction(action);
        }
    }

    // ------------------------------------------------------------------ convert

    private String fieldText(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(MAX_PREVIEW + 1, 0);
        CharSequence after = ic.getTextAfterCursor(MAX_PREVIEW + 1, 0);
        return (before == null ? "" : before.toString()) + (after == null ? "" : after.toString());
    }

    /** Replace everything in the field without reading it first. */
    private void replaceAllBlind(InputConnection ic, String text) {
        ic.beginBatchEdit();
        if (selStart != selEnd) ic.commitText("", 1);                   // drop a selection first
        ic.deleteSurroundingText(MAX_PREVIEW * 4, MAX_PREVIEW * 4);     // everything around the cursor
        ic.commitText(text, 1);
        ic.endBatchEdit();
    }

    /** Turn the plain text into the converted message and put it in the field. */
    private boolean convertNow(InputConnection ic, String plain) {
        if (plain.isEmpty() || plain.length() > MAX_PREVIEW) return false;
        if (plain.indexOf('\u2066') >= 0 || plain.indexOf('\u202e') >= 0) return false;   // already converted
        Converter.Result r = Converter.convert(plain, rloOn(), zwjOn());
        replaceAllBlind(ic, r.text);
        undoOriginal = plain;
        undoConverted = r.text;
        shadow = r.text;
        shadowKnown = true;
        selStart = selEnd = r.text.length();
        lastPreview = "";
        refreshAll();
        return true;
    }

    /** Put the plain text back in the field (before editing, or when you tap undo). */
    private void restorePlain(InputConnection ic) {
        String plain = undoOriginal;
        undoOriginal = null;
        undoConverted = null;
        lastPreview = "";
        if (plain != null) {
            replaceAllBlind(ic, plain);
            shadow = plain;
            shadowKnown = true;
            selStart = selEnd = plain.length();
        }
        refreshAll();
    }

    /** Tap the status pill: convert now, or undo. */
    private void toggleConvert() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        handler.removeCallbacks(autoConvert);
        if (undoConverted != null) {
            restorePlain(ic);
            return;
        }
        if (!shadowKnown) {
            shadow = fieldText(ic);
            shadowKnown = true;
        }
        convertNow(ic, shadow);
    }

    private void scheduleAuto() {
        handler.removeCallbacks(autoConvert);
        if (autoOn() && undoConverted == null) handler.postDelayed(autoConvert, AUTO_DELAY_MS);
    }

    /** Typing paused: convert the field by itself. */
    private void autoConvertNow() {
        if (!autoOn() || undoConverted != null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (!shadowKnown) {
            shadow = fieldText(ic);
            shadowKnown = true;
        }
        convertNow(ic, shadow);
    }

    // ------------------------------------------------------------------ live status (points + chars)

    /** Count again shortly after the text changes; the short delay also coalesces fast keystrokes. */
    private void schedulePoints() {
        handler.removeCallbacks(refreshPoints);
        handler.postDelayed(refreshPoints, 40);
    }

    private void scheduleReconcile(long delayMs) {
        handler.removeCallbacks(reconcile);
        handler.postDelayed(reconcile, delayMs);
    }

    /** Read the real text once (typing has paused) and fix the keyboard's own copy if it drifted. */
    private void reconcileNow() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        String real = fieldText(ic);
        boolean changedOutside = false;
        if (undoConverted != null) {
            if (!real.equals(undoConverted)) {      // the app changed it (sent and cleared, or edited)
                undoOriginal = null;
                undoConverted = null;
                shadow = real;
                shadowKnown = true;
                lastPreview = "";
                changedOutside = true;
            }
        } else if (!shadowKnown || !real.equals(shadow)) {
            shadow = real;
            shadowKnown = true;
            lastPreview = "";
            changedOutside = true;
        }
        refreshAll();
        if (changedOutside) scheduleAuto();         // text arrived from outside (paste, draft): convert it too
    }

    private void updatePointsNow() {
        refreshAll();
    }

    private void refreshAll() {
        updateStatus();
    }

    /** Points and characters, live. Uses only the keyboard's own copy of the text, never the app. */
    private void updateStatus() {
        if (statusKey == null) return;
        int budget = Converter.POINT_BUDGET;

        if (undoConverted != null && undoOriginal != null) {            // converted and ready to send
            int chars = undoOriginal.codePointCount(0, undoOriginal.length());
            int pts = undoConverted.codePointCount(0, undoConverted.length());
            showStatus(pts + "/" + budget + " pts", chars + " chars \u00B7 ready", pts, true);
            return;
        }
        if (!shadowKnown) return;
        String all = shadow;
        if (all.indexOf('\u2066') >= 0 || all.indexOf('\u202e') >= 0) {   // converted text that was already in the box
            int pts = all.codePointCount(0, all.length());
            showStatus(pts + "/" + budget + " pts", "converted", pts, true);
            return;
        }
        boolean rlo = rloOn();
        boolean zwj = zwjOn();
        String key = rlo + "|" + zwj + "|" + all;
        if (key.equals(lastPreview)) return;       // nothing changed since the last count
        lastPreview = key;

        int chars = all.codePointCount(0, all.length());
        if (all.isEmpty()) {
            showStatus("0/" + budget + " pts", "0 chars", 0, false);
        } else if (all.length() > MAX_PREVIEW) {
            showStatus("too long", chars + " chars", budget + 1, false);
        } else {
            Converter.Result r = Converter.convert(all, rlo, zwj);
            showStatus(r.points + "/" + budget + " pts", chars + " chars", r.points, false);
        }
    }

    private void showStatus(String main, String sub, int pts, boolean ready) {
        int budget = Converter.POINT_BUDGET;
        int tint = pts > budget ? RED : (pts * 100 > budget * 80 ? AMBER : MINT);
        statusKey.setLabel(main);
        statusKey.setSubLabel(sub);
        statusKey.setTextTint(pts > budget ? RED : FG);
        statusKey.setProgress(Math.min(1f, pts / (float) budget), tint);
        statusKey.setOutline(ready ? MINT : (pts > budget ? RED : 0));
    }

    // ------------------------------------------------------------------ clipboard history

    private String currentClipboardText() {
        try {
            ClipData data = clipboard.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return null;
            CharSequence text = data.getItemAt(0).coerceToText(this);
            if (text == null) return null;
            String s = text.toString();
            if (s.trim().isEmpty()) return null;
            return s.replace(SEP, " ");
        } catch (Exception e) {
            return null;     // clipboard can be unreadable at times
        }
    }

    /** fromCopy = a real copy just happened. Otherwise this is only a sync, which must not revive removed clips. */
    private void captureClipboard(boolean fromCopy) {
        String s = currentClipboardText();
        if (s == null) return;
        if (fromCopy) blockedClip = null;
        else if (s.equals(blockedClip)) return;
        addClip(s);
    }

    private void removeClip(String s) {
        clips.remove(s);
        pins.remove(s);
        saveClips();
        savePins();
        if (s.equals(currentClipboardText())) {
            blockedClip = s;
            clearSystemClipboard();
        }
        rebuildClipList();
    }

    private void clearAllClips() {
        clips.clear();
        saveClips();
        blockedClip = currentClipboardText();
        clearSystemClipboard();
        rebuildClipList();
    }

    private void clearSystemClipboard() {
        try {
            if (Build.VERSION.SDK_INT >= 28) clipboard.clearPrimaryClip();
            else clipboard.setPrimaryClip(ClipData.newPlainText("", ""));
        } catch (Exception ignored) {
            // if it cannot be cleared, blockedClip still keeps it from coming back
        }
    }

    private void addClip(String s) {
        if (pins.contains(s)) return;            // already pinned: it stays where it is
        clips.remove(s);
        clips.add(0, s);
        while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
        saveClips();
    }

    private void loadClips() {
        clips.clear();
        pins.clear();
        String raw = prefs.getString("clips", "");
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(SEP)) if (!s.isEmpty()) clips.add(s);
        }
        String pinned = prefs.getString("pins", "");
        if (pinned != null && !pinned.isEmpty()) {
            for (String s : pinned.split(SEP)) if (!s.isEmpty() && !pins.contains(s)) pins.add(s);
        }
        clips.removeAll(pins);                    // never list a clip twice
    }

    private void saveClips() {
        prefs.edit().putString("clips", TextUtils.join(SEP, clips)).apply();
    }

    private void savePins() {
        prefs.edit().putString("pins", TextUtils.join(SEP, pins)).apply();
    }
}
