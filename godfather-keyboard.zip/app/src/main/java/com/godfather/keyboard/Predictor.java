package com.godfather.keyboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Word suggestions for the keyboard. Pure Java, so it can be tested without a phone.
 *
 *  - Autocomplete: the dictionary is one alphabetically sorted array, so every word that starts
 *    with what you typed is a contiguous slice found by binary search (compact, no tree objects).
 *    The slice is ranked by frequency score, plus a boost for words you use yourself.
 *  - Next word: small bigram and trigram tables ("see you" -> later, soon...) plus pairs learned from you.
 *  - Autocorrect: only for finished words that are not in the dictionary. Candidates share the
 *    first letter and are scored with a keyboard-aware edit distance: a slip to a neighbouring
 *    key is cheap, a transposition is cheap, anything else costs a full edit.
 *  - Learning: words and word pairs you type are counted on the device and exported as text.
 *
 * words.txt   : "word score" per line (higher score = more common). A real frequency list such
 *               as FrequencyWords en_50k.txt ("word count") can be dropped in unchanged.
 * bigrams.txt : "previous next count" or "two-back previous next count" per line;
 *               "<s>" as previous means start of a sentence.
 */
public final class Predictor {

    public static final String START = "<s>";

    private static final int USER_WORD_BASE = 60_000;
    private static final int USER_WORD_STEP = 40_000;
    private static final int BIGRAM_SCALE = 700_000;
    private static final int MAX_USER_WORDS = 3000;
    private static final int MAX_USER_BIGRAMS = 6000;

    private String[] words = new String[0];     // sorted alphabetically
    private int[] score = new int[0];

    private final Map<String, int[]> bigramIndex = new HashMap<>();      // previous -> {sum}
    private final Map<String, List<Pair>> bigrams = new HashMap<>();     // previous -> next words
    private final Map<String, int[]> trigramIndex = new HashMap<>();     // "two-back previous" -> {sum}
    private final Map<String, List<Pair>> trigrams = new HashMap<>();
    private final Map<String, Integer> userWords = new HashMap<>();
    private final Map<String, Map<String, Integer>> userBigrams = new HashMap<>();

    private static final class Pair {
        final String word;
        final int count;
        Pair(String word, int count) {
            this.word = word;
            this.count = count;
        }
    }

    public static final class Suggestion {
        public final String text;
        public final int score;
        Suggestion(String text, int score) {
            this.text = text;
            this.score = score;
        }
    }

    /** What the user is in the middle of: the word being typed and the word before it. */
    public static final class Context {
        public final String partial;     // letters typed so far in the current word ("" after a space)
        public final String previous;     // previous word, lower case, or START
        public final String previous2;    // the word before that, or ""
        Context(String partial, String previous, String previous2) {
            this.partial = partial;
            this.previous = previous;
            this.previous2 = previous2;
        }
    }

    // ------------------------------------------------------------------ loading

    public void load(InputStream wordStream, InputStream bigramStream) throws IOException {
        List<String> w = new ArrayList<>();
        List<Integer> s = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(wordStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                int cut = indexOfSeparator(line);
                if (cut <= 0) continue;
                String word = line.substring(0, cut).toLowerCase();
                int value;
                try {
                    value = Integer.parseInt(line.substring(cut + 1).trim());
                } catch (NumberFormatException e) {
                    continue;
                }
                w.add(word);
                s.add(value);
            }
        }
        Integer[] order = new Integer[w.size()];
        for (int i = 0; i < order.length; i++) order[i] = i;
        Arrays.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return w.get(a).compareTo(w.get(b));
            }
        });
        String[] sortedWords = new String[order.length];
        int[] sortedScores = new int[order.length];
        int n = 0;
        for (int i = 0; i < order.length; i++) {
            String word = w.get(order[i]);
            if (n > 0 && sortedWords[n - 1].equals(word)) {      // duplicate: keep the higher score
                sortedScores[n - 1] = Math.max(sortedScores[n - 1], s.get(order[i]));
                continue;
            }
            sortedWords[n] = word;
            sortedScores[n] = s.get(order[i]);
            n++;
        }
        words = Arrays.copyOf(sortedWords, n);
        score = Arrays.copyOf(sortedScores, n);

        if (bigramStream != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(bigramStream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] p = line.trim().split("\\s+");
                    if (p.length != 3 && p.length != 4) continue;
                    int count;
                    try {
                        count = Integer.parseInt(p[p.length - 1]);
                    } catch (NumberFormatException e) {
                        continue;
                    }
                    String key = p.length == 3 ? p[0] : p[0] + " " + p[1];
                    String next = p.length == 3 ? p[1] : p[2];
                    Map<String, List<Pair>> table = p.length == 3 ? bigrams : trigrams;
                    Map<String, int[]> sums = p.length == 3 ? bigramIndex : trigramIndex;
                    List<Pair> list = table.get(key);
                    if (list == null) {
                        list = new ArrayList<>();
                        table.put(key, list);
                        sums.put(key, new int[]{0});
                    }
                    list.add(new Pair(next, count));
                    sums.get(key)[0] += count;
                }
            }
        }
    }

    private static int indexOfSeparator(String line) {
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == ' ' || c == '\t') return i;
        }
        return -1;
    }

    public int size() {
        return words.length;
    }

    // ------------------------------------------------------------------ reading the typed text

    /** Split the text before the cursor into the word being typed and the two words before it. */
    public static Context parse(String text) {
        int end = text.length();
        int start = end;
        while (start > 0 && isWordChar(text.charAt(start - 1))) start--;
        String partial = text.substring(start, end);

        String previous = START;
        String previous2 = "";
        int i = start;
        while (i > 0 && text.charAt(i - 1) == ' ') i--;
        if (i > 0 && isWordChar(text.charAt(i - 1))) {
            int e2 = i;
            int s2 = e2;
            while (s2 > 0 && isWordChar(text.charAt(s2 - 1))) s2--;
            previous = text.substring(s2, e2).toLowerCase();

            int j = s2;
            while (j > 0 && text.charAt(j - 1) == ' ') j--;
            if (j > 0 && isWordChar(text.charAt(j - 1))) {
                int e3 = j;
                int s3 = e3;
                while (s3 > 0 && isWordChar(text.charAt(s3 - 1))) s3--;
                previous2 = text.substring(s3, e3).toLowerCase();
            } else if (j == 0) {
                previous2 = START;
            }
        }
        // after . ? ! or , the next word starts fresh, so previous stays START
        return new Context(partial, previous, previous2);
    }

    private static boolean isWordChar(char c) {
        return Character.isLetter(c) || c == '\'';
    }

    // ------------------------------------------------------------------ dictionary lookups

    private int lowerBound(String prefix) {
        int lo = 0, hi = words.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (words[mid].compareTo(prefix) < 0) lo = mid + 1;
            else hi = mid;
        }
        return lo;
    }

    private int indexOf(String word) {
        int i = lowerBound(word);
        return i < words.length && words[i].equals(word) ? i : -1;
    }

    /** True for dictionary words and for words the user has typed before. */
    public boolean knows(String word) {
        String w = word.toLowerCase();
        return indexOf(w) >= 0 || userWords.containsKey(w);
    }

    private int baseScore(String w) {
        int i = indexOf(w);
        int s = i >= 0 ? score[i] : 0;
        Integer u = userWords.get(w);
        if (u != null) s += USER_WORD_BASE + USER_WORD_STEP * Math.min(u, 20);
        return s;
    }

    private static int tableBoost(Map<String, List<Pair>> table, Map<String, int[]> sums,
                                  String key, String candidate, int base) {
        List<Pair> list = table.get(key);
        if (list == null) return 0;
        for (Pair p : list) {
            if (p.word.equals(candidate)) {
                return (int) ((long) BIGRAM_SCALE * p.count / Math.max(sums.get(key)[0], 1)) + base;
            }
        }
        return 0;
    }

    private int contextBoost(Context ctx, String candidate) {
        int boost = tableBoost(bigrams, bigramIndex, ctx.previous, candidate, 150_000);
        if (!ctx.previous2.isEmpty()) {
            boost += tableBoost(trigrams, trigramIndex, ctx.previous2 + " " + ctx.previous, candidate, 350_000);
        }
        Map<String, Integer> mine = userBigrams.get(ctx.previous);
        if (mine != null) {
            Integer c = mine.get(candidate);
            if (c != null) boost += 200_000 + 40_000 * Math.min(c, 10);
        }
        return boost;
    }

    /** With nothing typed yet the context decides (how often this word followed); otherwise frequency still counts. */
    private int nextScore(Context ctx, String w, boolean contextLeads) {
        return contextLeads ? baseScore(w) / 5 + contextBoost(ctx, w) * 3 : baseScore(w) + contextBoost(ctx, w);
    }

    private void addContextNexts(Context ctx, String prefix, Map<String, Integer> found) {
        boolean contextLeads = prefix.isEmpty();
        List<List<Pair>> sources = new ArrayList<>();
        sources.add(bigrams.get(ctx.previous));
        if (!ctx.previous2.isEmpty()) sources.add(trigrams.get(ctx.previous2 + " " + ctx.previous));
        for (List<Pair> list : sources) {
            if (list == null) continue;
            for (Pair p : list) {
                if (p.word.startsWith(prefix)) found.put(p.word, nextScore(ctx, p.word, contextLeads));
            }
        }
        Map<String, Integer> mine = userBigrams.get(ctx.previous);
        if (mine != null) {
            for (String w : mine.keySet()) {
                if (w.startsWith(prefix)) found.put(w, nextScore(ctx, w, contextLeads));
            }
        }
    }

    // ------------------------------------------------------------------ suggestions

    /** Up to max suggestions for what is being typed (best first). */
    public List<Suggestion> suggest(Context ctx, int max) {
        String partial = ctx.partial.toLowerCase();
        Map<String, Integer> found = new HashMap<>();

        if (partial.isEmpty()) {
            nextWords(ctx, found);
        } else {
            completions(partial, ctx, found);
            if (found.size() < max && partial.length() >= 3) corrections(partial, ctx, found, max - found.size());
        }

        List<Suggestion> out = new ArrayList<>();
        for (Map.Entry<String, Integer> e : found.entrySet()) out.add(new Suggestion(e.getKey(), e.getValue()));
        out.sort((a, b) -> b.score != a.score ? Integer.compare(b.score, a.score) : a.text.compareTo(b.text));
        if (out.size() > max) out = new ArrayList<>(out.subList(0, max));
        return out;
    }

    private void completions(String partial, Context ctx, Map<String, Integer> found) {
        int lo = lowerBound(partial);
        // the best few by plain frequency inside the prefix slice
        int keep = 6;
        int[] bestIdx = new int[keep];
        int[] bestScore = new int[keep];
        Arrays.fill(bestIdx, -1);
        Arrays.fill(bestScore, Integer.MIN_VALUE);
        for (int i = lo; i < words.length && words[i].startsWith(partial); i++) {
            int s = score[i];
            if (s <= bestScore[keep - 1]) continue;
            int pos = keep - 1;
            while (pos > 0 && s > bestScore[pos - 1]) {
                bestScore[pos] = bestScore[pos - 1];
                bestIdx[pos] = bestIdx[pos - 1];
                pos--;
            }
            bestScore[pos] = s;
            bestIdx[pos] = i;
        }
        for (int k = 0; k < keep; k++) {
            if (bestIdx[k] < 0) continue;
            String w = words[bestIdx[k]];
            found.put(w, baseScore(w) + contextBoost(ctx, w));
        }
        // words you type yourself, and words the context usually leads to, that start the same way
        for (String w : userWords.keySet()) {
            if (w.startsWith(partial)) found.put(w, baseScore(w) + contextBoost(ctx, w));
        }
        addContextNexts(ctx, partial, found);
    }

    private void nextWords(Context ctx, Map<String, Integer> found) {
        addContextNexts(ctx, "", found);
        if (found.size() < 3) {            // fall back to the words people start or continue with most
            String[] filler = START.equals(ctx.previous)
                    ? new String[]{"i", "hey", "the", "you", "what", "how"}
                    : new String[]{"the", "you", "i", "to", "and", "it"};
            int bonus = 0;
            for (String w : filler) {
                if (!found.containsKey(w) && !w.equals(ctx.previous)) found.put(w, baseScore(w) / 8 - bonus);
                bonus += 100;
            }
        }
    }

    // ------------------------------------------------------------------ keyboard-aware spelling

    private static final String[] ROWS = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
    private static final boolean[][] NEAR = new boolean[26][26];

    static {
        for (int r = 0; r < ROWS.length; r++) {
            for (int c = 0; c < ROWS[r].length(); c++) {
                char a = ROWS[r].charAt(c);
                for (int r2 = 0; r2 < ROWS.length; r2++) {
                    for (int c2 = 0; c2 < ROWS[r2].length(); c2++) {
                        char b = ROWS[r2].charAt(c2);
                        // neighbours: same row next to each other, or the row above/below within one column
                        double x1 = c + (r == 1 ? 0.5 : r == 2 ? 1.0 : 0.0);
                        double x2 = c2 + (r2 == 1 ? 0.5 : r2 == 2 ? 1.0 : 0.0);
                        if (a != b && Math.abs(r - r2) <= 1 && Math.abs(x1 - x2) <= 1.01) {
                            NEAR[a - 'a'][b - 'a'] = true;
                        }
                    }
                }
            }
        }
    }

    private static double subCost(char a, char b) {
        if (a == b) return 0.0;
        if (a >= 'a' && a <= 'z' && b >= 'a' && b <= 'z' && NEAR[a - 'a'][b - 'a']) return 0.5;
        return 1.0;
    }

    /** Edit distance where a slip to a neighbouring key is cheap and a swap of two letters is cheap. */
    static double distance(String s, String t) {
        int n = s.length(), m = t.length();
        double[][] d = new double[n + 1][m + 1];
        d[0][0] = 0;
        for (int i = 1; i <= n; i++) d[i][0] = d[i - 1][0] + ((i > 1 && s.charAt(i - 1) == s.charAt(i - 2)) ? 0.4 : 1.0);
        for (int j = 1; j <= m; j++) d[0][j] = d[0][j - 1] + ((j > 1 && t.charAt(j - 1) == t.charAt(j - 2)) ? 0.4 : 1.0);
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                double del = (i > 1 && s.charAt(i - 1) == s.charAt(i - 2)) ? 0.4 : 1.0;   // dropped a doubled letter
                double ins = (j > 1 && t.charAt(j - 1) == t.charAt(j - 2)) ? 0.4 : 1.0;   // missed a doubled letter
                double best = Math.min(d[i - 1][j] + del, d[i][j - 1] + ins);
                best = Math.min(best, d[i - 1][j - 1] + subCost(s.charAt(i - 1), t.charAt(j - 1)));
                if (i > 1 && j > 1 && s.charAt(i - 1) == t.charAt(j - 2) && s.charAt(i - 2) == t.charAt(j - 1)) {
                    best = Math.min(best, d[i - 2][j - 2] + 0.7);
                }
                d[i][j] = best;
            }
        }
        return d[n][m];
    }

    private static final int COST_WEIGHT = 450_000;      // how much one full edit counts against a word
    private static final int MIN_TARGET = 30_000;         // never "correct" to obscure words

    /** Best close word for a misspelled one: cost and how common the word is, weighed together. */
    private Suggestion closest(String typed, Context ctx, double maxCost) {
        Suggestion best = null;
        long bestValue = Long.MIN_VALUE;

        // two neighbouring letters swapped, wherever they are (also the first two: "teh" -> "the")
        for (int k = 0; k + 1 < typed.length(); k++) {
            char[] c = typed.toCharArray();
            char tmp = c[k];
            c[k] = c[k + 1];
            c[k + 1] = tmp;
            String swapped = new String(c);
            if (!swapped.equals(typed) && indexOf(swapped) >= 0) {
                int sc = baseScore(swapped) + contextBoost(ctx, swapped);
                long value = sc - (long) (0.7 * COST_WEIGHT);
                if (value > bestValue) {
                    bestValue = value;
                    best = new Suggestion(swapped, sc);
                }
            }
        }
        if (typed.length() <= 3) return best;           // very short words: only a swap is trusted

        char first = typed.charAt(0);
        int lo = lowerBound(String.valueOf(first));
        for (int i = lo; i < words.length && words[i].charAt(0) == first; i++) {
            String w = words[i];
            if (Math.abs(w.length() - typed.length()) > 1 || score[i] < MIN_TARGET) continue;
            double cost = distance(typed, w);
            if (cost > maxCost) continue;
            int sc = baseScore(w) + contextBoost(ctx, w);
            long value = sc - (long) (cost * COST_WEIGHT);
            if (value > bestValue) {
                bestValue = value;
                best = new Suggestion(w, sc);
            }
        }
        return best;
    }

    private void corrections(String partial, Context ctx, Map<String, Integer> found, int room) {
        char first = partial.charAt(0);
        int lo = lowerBound(String.valueOf(first));
        List<Suggestion> close = new ArrayList<>();
        for (int i = lo; i < words.length && words[i].charAt(0) == first; i++) {
            String w = words[i];
            if (Math.abs(w.length() - partial.length()) > 1 || score[i] < MIN_TARGET || found.containsKey(w)) continue;
            double cost = distance(partial, w);
            if (cost <= 1.0) {
                close.add(new Suggestion(w, baseScore(w) + contextBoost(ctx, w) - (int) (cost * COST_WEIGHT)));
            }
        }
        close.sort((a, b) -> Integer.compare(b.score, a.score));
        for (int k = 0; k < Math.min(room, close.size()); k++) found.put(close.get(k).text, close.get(k).score);
    }

    private static final Map<String, String> CONTRACTIONS = new HashMap<>();

    static {
        String[] pairs = {
            "dont", "don't", "cant", "can't", "wont", "won't", "im", "i'm", "ive", "i've", "youre", "you're",
            "youve", "you've", "youll", "you'll", "thats", "that's", "whats", "what's", "isnt", "isn't",
            "didnt", "didn't", "doesnt", "doesn't", "couldnt", "couldn't", "wouldnt", "wouldn't",
            "shouldnt", "shouldn't", "wasnt", "wasn't", "werent", "weren't", "arent", "aren't",
            "hasnt", "hasn't", "havent", "haven't", "hadnt", "hadn't", "theyre", "they're", "theres", "there's",
            "heres", "here's", "hes", "he's", "shes", "she's", "weve", "we've", "ill", "i'll", "wheres", "where's"
        };
        for (int i = 0; i < pairs.length; i += 2) CONTRACTIONS.put(pairs[i], pairs[i + 1]);
        CONTRACTIONS.remove("ill");     // "ill" is a real word; leave it alone
    }

    /**
     * The word to swap in for a finished word, or null to leave it alone. Careful on purpose:
     * words that are known (dictionary or yours) and very short words are never changed.
     */
    public String correct(String typed, String previous) {
        return correct(typed, new Context("", previous == null ? START : previous, ""));
    }

    public String correct(String typed, Context ctx) {
        String t = typed.toLowerCase();
        String contraction = CONTRACTIONS.get(t);
        if (contraction != null) return contraction;
        if (t.length() < 3 || knows(t) || !t.chars().allMatch(c -> c >= 'a' && c <= 'z')) return null;
        double limit = t.length() >= 8 ? 1.2 : 1.0;
        Suggestion s = closest(t, ctx, limit);
        return s == null ? null : s.text;
    }

    // ------------------------------------------------------------------ learning (on this phone only)

    public void learn(String word, String previous) {
        String w = word.toLowerCase();
        if (w.length() < 2 && !w.equals("i") && !w.equals("u")) return;
        if (!w.chars().allMatch(c -> Character.isLetter(c) || c == '\'')) return;
        userWords.merge(w, 1, Integer::sum);
        if (previous != null && !previous.isEmpty()) {
            userBigrams.computeIfAbsent(previous, k -> new HashMap<>()).merge(w, 1, Integer::sum);
        }
        prune();
    }

    /** Make sure a word is never auto-corrected again (the user undid a correction). */
    public void protect(String word) {
        String w = word.toLowerCase();
        userWords.merge(w, 3, Integer::sum);
    }

    private void prune() {
        if (userWords.size() > MAX_USER_WORDS) {
            List<Map.Entry<String, Integer>> list = new ArrayList<>(userWords.entrySet());
            list.sort((a, b) -> Integer.compare(a.getValue(), b.getValue()));
            for (int i = 0; i < list.size() / 4; i++) userWords.remove(list.get(i).getKey());
        }
        int total = 0;
        for (Map<String, Integer> m : userBigrams.values()) total += m.size();
        if (total > MAX_USER_BIGRAMS) {
            for (Map<String, Integer> m : userBigrams.values()) m.values().removeIf(v -> v <= 1);
            userBigrams.values().removeIf(Map::isEmpty);
        }
    }

    /** Lines "w word count" and "b previous next count". */
    public String exportUser() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : userWords.entrySet()) {
            sb.append("w ").append(e.getKey()).append(' ').append(e.getValue()).append('\n');
        }
        for (Map.Entry<String, Map<String, Integer>> e : userBigrams.entrySet()) {
            for (Map.Entry<String, Integer> f : e.getValue().entrySet()) {
                sb.append("b ").append(e.getKey()).append(' ').append(f.getKey()).append(' ')
                        .append(f.getValue()).append('\n');
            }
        }
        return sb.toString();
    }

    public void importUser(String text) {
        if (text == null || text.isEmpty()) return;
        for (String line : text.split("\n")) {
            String[] p = line.split(" ");
            try {
                if (p.length == 3 && p[0].equals("w")) {
                    userWords.put(p[1], Integer.parseInt(p[2]));
                } else if (p.length == 4 && p[0].equals("b")) {
                    userBigrams.computeIfAbsent(p[1], k -> new HashMap<>()).put(p[2], Integer.parseInt(p[3]));
                }
            } catch (NumberFormatException ignored) {
                // skip a damaged line
            }
        }
    }
}
