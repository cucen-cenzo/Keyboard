package com.godfather.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Setup screen: shows whether the keyboard is on and selected (and updates itself when you come
 * back from system settings), has your settings, and a box to try it in.
 */
public class SetupActivity extends Activity {

    private static final int BG = 0xFF050507;
    private static final int CARD = 0xFF111114;
    private static final int EDGE = 0x1AFFFFFF;
    private static final int TEXT = 0xFFF2F3F5;
    private static final int MUTED = 0xFF8E95A3;
    private static final String[] ACCENT_NAMES = {"Mint", "Sky", "Violet", "Rose", "Amber"};

    private SharedPreferences prefs;
    private float density;

    private TextView statusLine;
    private TextView badge1, sub1, badge2, sub2;
    private View card2;
    private TextView heightValue;
    private SeekBar heightBar;
    private Switch swipeSwitch;
    private TextView accentName;
    private final List<View> rings = new ArrayList<>();

    private int dp(float v) {
        return Math.round(v * density);
    }

    private int accent() {
        int i = Math.max(0, Math.min(GodfatherIME.ACCENTS.length - 1, prefs.getInt("accent", 0)));
        return GodfatherIME.ACCENTS[i];
    }

    /** Saves one setting and bumps the revision so the keyboard rebuilds itself next time it opens. */
    private void touch(SharedPreferences.Editor editor) {
        editor.putLong("settingsRev", System.currentTimeMillis()).apply();
    }

    // ------------------------------------------------------------------ small view helpers

    private TextView text(String s, float sp, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }

    private GradientDrawable rounded(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    private GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(0, dp(10), 0, dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(4);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView sectionLabel(String s) {
        TextView t = text(s.toUpperCase(), 12, MUTED, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(4), dp(14), 0, dp(10));
        return t;
    }

    /** Presses shrink slightly and settle back with an ease-out, so taps feel acknowledged. */
    private void pressable(final View v, final float pressedScale) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(pressedScale).scaleY(pressedScale).setDuration(90)
                            .setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(160)
                            .setInterpolator(new DecelerateInterpolator(2f)).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    // ------------------------------------------------------------------ build

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("godfather", MODE_PRIVATE);
        density = getResources().getDisplayMetrics().density;
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(20), dp(48), dp(20), dp(32));

        // ---- header
        TextView title = text("Godfather", 38, TEXT, true);
        title.setLetterSpacing(-0.02f);
        root.addView(title);
        statusLine = text("", 16, MUTED, false);
        statusLine.setPadding(0, dp(6), 0, dp(14));
        root.addView(statusLine);

        // ---- step 1 and 2
        LinearLayout step1 = card();
        badge1 = badge();
        sub1 = text("", 14, MUTED, false);
        step1.addView(stepRow(badge1, "Turn on the keyboard", sub1));
        step1.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        pressable(step1, 0.98f);
        root.addView(step1);

        LinearLayout step2 = card();
        card2 = step2;
        badge2 = badge();
        sub2 = text("", 14, MUTED, false);
        step2.addView(stepRow(badge2, "Switch to it", sub2));
        step2.setOnClickListener(v -> {
            if (!isEnabled()) {                       // can't pick it yet: send them to turn it on
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
                return;
            }
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        pressable(step2, 0.98f);
        root.addView(step2);

        // ---- settings
        root.addView(sectionLabel("Settings"));
        LinearLayout settings = card();

        int height = Math.max(80, Math.min(130, prefs.getInt("keyHeight", 100)));
        LinearLayout heightRow = new LinearLayout(this);
        heightRow.setOrientation(LinearLayout.HORIZONTAL);
        heightRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView heightLabel = text("Key height", 16, TEXT, true);
        heightRow.addView(heightLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        heightValue = text(height + "%", 15, MUTED, false);
        heightRow.addView(heightValue);
        settings.addView(heightRow);

        heightBar = new SeekBar(this);
        heightBar.setMax(50);                        // 80% .. 130%
        heightBar.setProgress(height - 80);
        heightBar.setPadding(dp(4), dp(10), dp(4), dp(10));
        heightBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int pct = 80 + progress;
                heightValue.setText(pct + "%");
                if (fromUser) touch(prefs.edit().putInt("keyHeight", pct));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        settings.addView(heightBar);

        settings.addView(divider());

        LinearLayout accentRow = new LinearLayout(this);
        accentRow.setOrientation(LinearLayout.HORIZONTAL);
        accentRow.setGravity(Gravity.CENTER_VERTICAL);
        accentRow.addView(text("Accent colour", 16, TEXT, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        accentName = text("", 15, MUTED, false);
        accentRow.addView(accentName);
        accentRow.setPadding(0, dp(4), 0, dp(10));
        settings.addView(accentRow);

        LinearLayout swatchRow = new LinearLayout(this);
        swatchRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < GodfatherIME.ACCENTS.length; i++) {
            final int index = i;
            FrameLayout swatch = new FrameLayout(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
            lp.rightMargin = dp(8);
            swatch.setLayoutParams(lp);
            String name = index < ACCENT_NAMES.length ? ACCENT_NAMES[index] : "Colour " + (index + 1);
            swatch.setContentDescription(name);

            View ring = new View(this);
            GradientDrawable r = new GradientDrawable();
            r.setShape(GradientDrawable.OVAL);
            r.setColor(Color.TRANSPARENT);
            r.setStroke(dp(2), 0xFFFFFFFF);
            ring.setBackground(r);
            ring.setAlpha(0f);
            swatch.addView(ring, new FrameLayout.LayoutParams(dp(48), dp(48)));
            rings.add(ring);

            View dot = new View(this);
            dot.setBackground(oval(GodfatherIME.ACCENTS[i]));
            FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER);
            swatch.addView(dot, dlp);

            swatch.setOnClickListener(v -> {
                touch(prefs.edit().putInt("accent", index));
                applyAccent(true);
            });
            pressable(swatch, 0.92f);
            swatchRow.addView(swatch);
        }
        settings.addView(swatchRow);

        settings.addView(divider());

        LinearLayout swipeRow = new LinearLayout(this);
        swipeRow.setOrientation(LinearLayout.HORIZONTAL);
        swipeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout swipeText = new LinearLayout(this);
        swipeText.setOrientation(LinearLayout.VERTICAL);
        swipeText.addView(text("Swipe gestures", 16, TEXT, true));
        TextView swipeHint = text("Slide on the space bar to move the cursor. Slide left on backspace to delete words.",
                13, MUTED, false);
        swipeHint.setPadding(0, dp(3), dp(12), 0);
        swipeText.addView(swipeHint);
        swipeRow.addView(swipeText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        swipeSwitch = new Switch(this);
        swipeSwitch.setChecked(prefs.getBoolean("swipe", true));
        swipeSwitch.setOnCheckedChangeListener((button, on) -> touch(prefs.edit().putBoolean("swipe", on)));
        swipeRow.addView(swipeSwitch);
        settings.addView(swipeRow);

        root.addView(settings);

        TextView note = text("Changes apply the next time the keyboard opens.", 13, MUTED, false);
        note.setPadding(dp(4), 0, 0, dp(6));
        root.addView(note);

        // ---- try it
        root.addView(sectionLabel("Try it here"));
        EditText test = new EditText(this);
        test.setHint("Type something…");
        test.setHintTextColor(0xFF5E6674);
        test.setTextColor(TEXT);
        test.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        test.setGravity(Gravity.TOP | Gravity.START);
        test.setMinLines(4);
        test.setBackground(rounded(CARD, 14, 0));
        test.setPadding(dp(16), dp(14), dp(16), dp(14));
        test.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(test, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        applyAccent(false);
        refreshStatus();

        // Things arrive one after another with a short ease-out, only the first time the screen opens.
        if (savedInstanceState == null) {
            for (int i = 0; i < root.getChildCount(); i++) {
                View child = root.getChildAt(i);
                child.setAlpha(0f);
                child.setTranslationY(dp(14));
                child.animate().alpha(1f).translationY(0f).setStartDelay(i * 40L).setDuration(320)
                        .setInterpolator(new DecelerateInterpolator(2.2f)).start();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();                              // coming back from system settings or the picker
    }

    // ------------------------------------------------------------------ pieces

    private TextView badge() {
        TextView b = text("", 15, MUTED, true);
        b.setGravity(Gravity.CENTER);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        return b;
    }

    private LinearLayout stepRow(TextView badge, String title, TextView sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(badge);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, dp(8), 0);
        col.addView(text(title, 17, TEXT, true));
        sub.setPadding(0, dp(2), 0, 0);
        col.addView(sub);
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(text("›", 24, MUTED, false));
        return row;
    }

    private View divider() {
        View d = new View(this);
        d.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22)));
        return d;
    }

    // ------------------------------------------------------------------ state

    private boolean isEnabled() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return false;
        for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
            if (getPackageName().equals(info.getPackageName())) return true;
        }
        return false;
    }

    private boolean isSelected() {
        String current = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return current != null && current.startsWith(getPackageName() + "/");
    }

    private void setStep(TextView badge, TextView sub, int number, boolean done, String doneText, String todoText) {
        int a = accent();
        if (done) {
            badge.setText("✓");
            badge.setTextColor(0xFF08080A);
            badge.setBackground(oval(a));
            sub.setText(doneText);
            sub.setTextColor(a);
        } else {
            badge.setText(String.valueOf(number));
            badge.setTextColor(MUTED);
            badge.setBackground(oval(0x22FFFFFF));
            sub.setText(todoText);
            sub.setTextColor(MUTED);
        }
    }

    private void refreshStatus() {
        boolean enabled = isEnabled();
        boolean selected = enabled && isSelected();
        setStep(badge1, sub1, 1, enabled, "On", "Tap to turn it on in system settings");
        setStep(badge2, sub2, 2, selected, "In use",
                enabled ? "Pick Godfather in the list that appears" : "Turn it on first");
        card2.setAlpha(enabled ? 1f : 0.55f);
        if (enabled && selected) {
            statusLine.setText("You're all set. Type anywhere.");
            statusLine.setTextColor(accent());
        } else {
            statusLine.setText("Two quick steps and you're typing.");
            statusLine.setTextColor(MUTED);
        }
    }

    /** Re-colours everything that follows the accent: slider, switch, ring, preview and the step badges. */
    private void applyAccent(boolean animate) {
        int a = accent();
        int chosen = Math.max(0, Math.min(GodfatherIME.ACCENTS.length - 1, prefs.getInt("accent", 0)));
        for (int i = 0; i < rings.size(); i++) {
            float target = i == chosen ? 1f : 0f;
            if (animate) {
                rings.get(i).animate().alpha(target).setDuration(160)
                        .setInterpolator(new DecelerateInterpolator(2f)).start();
            } else {
                rings.get(i).setAlpha(target);
            }
        }
        accentName.setText(chosen < ACCENT_NAMES.length ? ACCENT_NAMES[chosen] : "Colour " + (chosen + 1));
        heightBar.setProgressTintList(ColorStateList.valueOf(a));
        heightBar.setThumbTintList(ColorStateList.valueOf(a));
        heightBar.setProgressBackgroundTintList(ColorStateList.valueOf(0x33FFFFFF));
        int[][] states = {{android.R.attr.state_checked}, {}};
        swipeSwitch.setThumbTintList(new ColorStateList(states, new int[]{a, 0xFF9AA0AC}));
        swipeSwitch.setTrackTintList(new ColorStateList(states, new int[]{(a & 0x00FFFFFF) | 0x66000000, 0x33FFFFFF}));
        refreshStatus();
    }
}
