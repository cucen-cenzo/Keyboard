package com.godfather.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Setup screen: turn the keyboard on, switch to it, change its settings, and try it out. */
public class SetupActivity extends Activity {

    private SharedPreferences prefs;
    private float density;
    private final List<TextView> swatches = new ArrayList<>();

    private int dp(float v) {
        return Math.round(v * density);
    }

    /** Saves one setting and bumps the revision so the keyboard rebuilds itself next time it opens. */
    private void touch(SharedPreferences.Editor editor) {
        editor.putLong("settingsRev", System.currentTimeMillis()).apply();
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        return t;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("godfather", MODE_PRIVATE);
        density = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        int pad = dp(24);
        root.setPadding(pad, pad * 2, pad, pad);

        root.addView(text("godfather keyboard", 28, 0xFFECEEF2));

        TextView steps = text("1. Turn the keyboard on.\n2. Switch to it.\n3. Type in the box at the bottom. "
                + "Tap convert to change everything you typed, tap undo to go back.", 15, 0xFF9AA3B0);
        steps.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(steps);

        Button enable = new Button(this);
        enable.setAllCaps(false);
        enable.setText("1. Turn on Godfather keyboard");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button pick = new Button(this);
        pick.setAllCaps(false);
        pick.setText("2. Switch to it");
        pick.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(pick);

        // ---------------------------------------------------------------- settings
        TextView settingsTitle = text("Settings", 22, 0xFFECEEF2);
        settingsTitle.setPadding(0, pad, 0, dp(4));
        root.addView(settingsTitle);

        int height = Math.max(80, Math.min(130, prefs.getInt("keyHeight", 100)));
        final TextView heightLabel = text("Key height: " + height + "%", 16, 0xFFECEEF2);
        heightLabel.setPadding(0, dp(12), 0, 0);
        root.addView(heightLabel);
        SeekBar bar = new SeekBar(this);
        bar.setMax(50);                              // 80% .. 130%
        bar.setProgress(height - 80);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int pct = 80 + progress;
                heightLabel.setText("Key height: " + pct + "%");
                if (fromUser) touch(prefs.edit().putInt("keyHeight", pct));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        root.addView(bar);

        TextView accentLabel = text("Accent colour", 16, 0xFFECEEF2);
        accentLabel.setPadding(0, dp(16), 0, dp(8));
        root.addView(accentLabel);
        LinearLayout swatchRow = new LinearLayout(this);
        swatchRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < GodfatherIME.ACCENTS.length; i++) {
            final int index = i;
            TextView swatch = new TextView(this);
            swatch.setContentDescription("accent colour " + (i + 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.setMargins(0, 0, dp(12), 0);
            swatch.setLayoutParams(lp);
            swatch.setOnClickListener(v -> {
                touch(prefs.edit().putInt("accent", index));
                refreshSwatches();
            });
            swatches.add(swatch);
            swatchRow.addView(swatch);
        }
        root.addView(swatchRow);
        refreshSwatches();

        Switch swipe = new Switch(this);
        swipe.setText("Swipe gestures");
        swipe.setTextColor(0xFFECEEF2);
        swipe.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        swipe.setChecked(prefs.getBoolean("swipe", true));
        swipe.setOnCheckedChangeListener((button, on) -> touch(prefs.edit().putBoolean("swipe", on)));
        swipe.setPadding(0, dp(20), 0, 0);
        root.addView(swipe);
        TextView swipeHint = text("Slide on the space bar to move the cursor. Slide left on backspace to delete words.",
                13, 0xFF9AA3B0);
        swipeHint.setPadding(0, dp(4), 0, dp(8));
        root.addView(swipeHint);

        TextView note = text("Changes apply the next time the keyboard opens.", 13, 0xFF9AA3B0);
        note.setPadding(0, dp(4), 0, pad);
        root.addView(note);

        EditText test = new EditText(this);
        test.setHint("3. Try it here");
        test.setHintTextColor(0xFF616A77);
        test.setTextColor(0xFFECEEF2);
        test.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        test.setMinLines(3);
        root.addView(test, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.BLACK);
        scroll.setFillViewport(true);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    /** Draws each colour as a circle; the chosen one gets a white ring. */
    private void refreshSwatches() {
        int chosen = Math.max(0, Math.min(GodfatherIME.ACCENTS.length - 1, prefs.getInt("accent", 0)));
        for (int i = 0; i < swatches.size(); i++) {
            GradientDrawable dot = new GradientDrawable();
            dot.setShape(GradientDrawable.OVAL);
            dot.setColor(GodfatherIME.ACCENTS[i]);
            if (i == chosen) dot.setStroke(dp(3), Color.WHITE);
            swatches.get(i).setBackground(dot);
        }
    }
}
