package com.godfather.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tiny setup screen: turn the keyboard on, switch to it, and try it out. */
public class SetupActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        int pad = Math.round(24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("godfather keyboard");
        title.setTextColor(0xFFECEEF2);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        root.addView(title);

        TextView steps = new TextView(this);
        steps.setText("1. Turn the keyboard on.\n2. Switch to it.\n3. Type in the box below. "
                + "Tap convert to change everything you typed, tap undo to go back.");
        steps.setTextColor(0xFF9AA3B0);
        steps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        steps.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(steps);

        Button enable = new Button(this);
        enable.setAllCaps(false);
        enable.setText("1. Turn on Godfather keyboard");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button pick = new Button(this);
        pick.setAllCaps(false);
        pick.setText("2. Switch to it");
        pick.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(pick);

        EditText test = new EditText(this);
        test.setHint("3. Try it here");
        test.setHintTextColor(0xFF616A77);
        test.setTextColor(0xFFECEEF2);
        test.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        test.setMinLines(3);
        root.addView(test, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }
}
